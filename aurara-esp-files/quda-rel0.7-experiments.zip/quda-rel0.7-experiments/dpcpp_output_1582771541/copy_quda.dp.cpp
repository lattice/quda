#include <CL/sycl.hpp>
#include <dpct/dpct.hpp>
#include <blas_quda.h>
#include <tune_quda.h>
#include <float_vector.h>

// For kernels with precision conversion built in
#define checkSpinorLength(a, b)						\
  {									\
    if (a.Length() != b.Length())					\
      errorQuda("lengths do not match: %d %d", a.Length(), b.Length());	\
    if (a.Stride() != b.Stride())					\
      errorQuda("strides do not match: %d %d", a.Stride(), b.Stride());	\
  }

namespace quda {

/* DPCT_ORIG   cudaStream_t* getBlasStream();*/
  queue_p *getBlasStream();

  namespace copy {

#include <texture.h>

using queue_p = cl::sycl::queue *;

    static struct dpct_type_9e2ebf {
      const char *vol_str;
      const char *aux_str;      
    } blasStrings;

    template <typename FloatN, int N, typename Output, typename Input>
    /* DPCT_ORIG     __global__ void copyKernel(Output Y, Input X, int length)
       {*/
    void copyKernel(Output Y, Input X, int length,
                    cl::sycl::nd_item<3> item_ct1) {
/* DPCT_ORIG       unsigned int i = blockIdx.x*(blockDim.x) + threadIdx.x;*/
      unsigned int i =
          item_ct1.get_group(2) * (item_ct1.get_local_range().get(2)) +
          item_ct1.get_local_id(2);
/* DPCT_ORIG       unsigned int gridSize = gridDim.x*blockDim.x;*/
      unsigned int gridSize =
          item_ct1.get_group_range(2) * item_ct1.get_local_range().get(2);

      while (i < length) {
	FloatN x[N];
	X.load(x, i);
	Y.save(x, i);
	i += gridSize;
      }
    }

    template <typename FloatN, int N, typename Output, typename Input>
    class CopyCuda : public Tunable {

    private:
      Input &X;
      Output &Y;
      const int length;

      unsigned int sharedBytesPerThread() const { return 0; }
      unsigned int sharedBytesPerBlock(const TuneParam &param) const { return 0; }

      virtual bool advanceSharedBytes(TuneParam &param) const
      {
	TuneParam next(param);
	advanceBlockDim(next); // to get next blockDim
/* DPCT_ORIG 	int nthreads = next.block.x * next.block.y * next.block.z;*/
	int nthreads = next.block[0] * next.block[1] * next.block[2];
        param.shared_bytes = sharedBytesPerThread()*nthreads > sharedBytesPerBlock(param) ?
	  sharedBytesPerThread()*nthreads : sharedBytesPerBlock(param);
	return false;
      }

    public:
      CopyCuda(Output &Y, Input &X, int length) : X(X), Y(Y), length(length) { }
      virtual ~CopyCuda() { ; }

      inline TuneKey tuneKey() const {
	return TuneKey(blasStrings.vol_str, "copyKernel", blasStrings.aux_str); 
      }

/* DPCT_ORIG       inline void apply(const cudaStream_t &stream) {*/
      inline void apply(const queue_p &stream) {
        TuneParam tp = tuneLaunch(*this, getTuning(), getVerbosity());
/* DPCT_ORIG 	copyKernel<FloatN, N><<<tp.grid, tp.block, tp.shared_bytes,
 * stream>>>(Y, X, length);*/
	{
	  auto Y_ct0 = Y;
	  auto X_ct1 = X;
	  auto length_ct2 = length;
	  stream->submit([&](cl::sycl::handler &cgh) {
	      auto dpct_global_range = tp.grid * tp.block;
	      cgh.parallel_for(cl::sycl::nd_range<3>(
                            cl::sycl::range<3>(dpct_global_range.get(2),
                                               dpct_global_range.get(1),
                                               dpct_global_range.get(0)),
                            cl::sycl::range<3>(tp.block.get(2), tp.block.get(1),
                                               tp.block.get(0))),
                        [=](cl::sycl::nd_item<3> item_ct1) {
	          copyKernel<FloatN, N>(Y_ct0, X_ct1, length_ct2, item_ct1);
                        });
   });
	}
      }

      void preTune() { ; } // no need to save state for copy kernels
      void postTune() { ; } // no need to restore state for copy kernels

      long long flops() const { return 0; }
      long long bytes() const { 
	const int Ninternal = (sizeof(FloatN)/sizeof(((FloatN*)0)->x))*N;
	size_t bytes = (X.Precision() + Y.Precision())*Ninternal;
	if (X.Precision() == QUDA_HALF_PRECISION) bytes += sizeof(float);
	if (Y.Precision() == QUDA_HALF_PRECISION) bytes += sizeof(float);
	return bytes*length; 
      }
      int tuningIter() const { return 3; }
    };

    void copyCuda(cudaColorSpinorField &dst,
                  const cudaColorSpinorField &src) try {
      if (&src == &dst) return; // aliasing fields
      if (src.Nspin() != 1 && src.Nspin() != 4) errorQuda("nSpin(%d) not supported\n", src.Nspin());

      if (dst.SiteSubset() == QUDA_FULL_SITE_SUBSET || src.SiteSubset() == QUDA_FULL_SITE_SUBSET) {
	if (src.SiteSubset() != dst.SiteSubset()) 
	  errorQuda("Spinor fields do not have matching subsets dst=%d src=%d\n", 
		    dst.SiteSubset(), src.SiteSubset());
	copy::copyCuda(dst.Even(), src.Even());
	copy::copyCuda(dst.Odd(), src.Odd());
	return;
      }

      checkSpinorLength(dst, src);

      blasStrings.vol_str = src.VolString();
      char tmp[256];
      strcpy(tmp, "dst=");
      strcat(tmp, dst.AuxString());
      strcat(tmp, ",src=");
      strcat(tmp, src.AuxString());
      blasStrings.aux_str = tmp;

      // For a given dst precision, there are two non-trivial possibilities for the
      // src precision.

      // FIXME: use traits to encapsulate register type for shorts -
      // will reduce template type parameters from 3 to 2

      blas_bytes += (unsigned long long)src.RealLength()*(src.Precision() + dst.Precision());
      
      if (dst.Precision() == src.Precision()) {
	if (src.Bytes() != dst.Bytes()) errorQuda("Precisions match, but bytes do not");
/* DPCT_ORIG 	cudaMemcpy(dst.V(), src.V(), dst.Bytes(),
 * cudaMemcpyDeviceToDevice);*/
	dpct::get_default_queue_wait().memcpy(dst.V(), src.V(), dst.Bytes()).wait();
        if (dst.Precision() == QUDA_HALF_PRECISION) {
/* DPCT_ORIG 	  cudaMemcpy(dst.Norm(), src.Norm(), dst.NormBytes(),
 * cudaMemcpyDeviceToDevice);*/
	  dpct::get_default_queue_wait()
       .memcpy(dst.Norm(), src.Norm(), dst.NormBytes())
       .wait();
          blas_bytes += 2*(unsigned long long)dst.RealLength()*sizeof(float);
	}
      } else if (dst.Precision() == QUDA_DOUBLE_PRECISION && src.Precision() == QUDA_SINGLE_PRECISION) {
	if (src.Nspin() == 4){
	  Spinor<float4, float4, float4, 6, 0, 0> src_tex(src);
	  Spinor<float4, float2, double2, 6, 1> dst_spinor(dst);
	  CopyCuda<float4, 6, Spinor<float4, float2, double2, 6, 1>, 
		   Spinor<float4, float4, float4, 6, 0, 0> >
	    copy(dst_spinor, src_tex, src.Volume());
	  copy.apply(*getBlasStream());	
      } else { //src.Nspin() == 1
	  Spinor<float2, float2, float2, 3, 0, 0> src_tex(src);
	  Spinor<float2, float2, double2, 3, 1> dst_spinor(dst);
	  CopyCuda<float2, 3, Spinor<float2, float2, double2, 3, 1>,
		   Spinor<float2, float2, float2, 3, 0, 0> >
	    copy(dst_spinor, src_tex, src.Volume());
	  copy.apply(*getBlasStream());	
    } 
  } else if (dst.Precision() == QUDA_SINGLE_PRECISION && src.Precision() == QUDA_DOUBLE_PRECISION) {
	if (src.Nspin() == 4){
	  Spinor<float4, float2, double2, 6, 0, 0> src_tex(src);
	  Spinor<float4, float4, float4, 6, 1> dst_spinor(dst);
	  CopyCuda<float4, 6, Spinor<float4, float4, float4, 6, 1>,
		   Spinor<float4, float2, double2, 6, 0, 0> >
	    copy(dst_spinor, src_tex, src.Volume());
	  copy.apply(*getBlasStream());	
      } else { //src.Nspin() ==1
	  Spinor<float2, float2, double2, 3, 0, 0> src_tex(src);
	  Spinor<float2, float2, float2, 3, 1> dst_spinor(dst);
	  CopyCuda<float2, 3, Spinor<float2, float2, float2, 3, 1>,
		   Spinor<float2, float2, double2, 3, 0, 0> >
	  copy(dst_spinor, src_tex, src.Volume());
  copy.apply(*getBlasStream());	
}
  } else if (dst.Precision() == QUDA_SINGLE_PRECISION && src.Precision() == QUDA_HALF_PRECISION) {
	blas_bytes += (unsigned long long)src.Volume()*sizeof(float);
	if (src.Nspin() == 4){      
	  Spinor<float4, float4, short4, 6, 0, 0> src_tex(src);
	  Spinor<float4, float4, float4, 6, 1> dst_spinor(dst);
	  CopyCuda<float4, 6, Spinor<float4, float4, float4, 6, 1>,
		   Spinor<float4, float4, short4, 6, 0, 0> >
	    copy(dst_spinor, src_tex, src.Volume());
	  copy.apply(*getBlasStream());	
      } else { //nSpin== 1;
	  Spinor<float2, float2, short2, 3, 0, 0> src_tex(src);
	  Spinor<float2, float2, float2, 3, 1> dst_spinor(dst);
	  CopyCuda<float2, 3, Spinor<float2, float2, float2, 3, 1>,
		   Spinor<float2, float2, short2, 3, 0, 0> >
	    copy(dst_spinor, src_tex, src.Volume());
	  copy.apply(*getBlasStream());	
    }
  } else if (dst.Precision() == QUDA_HALF_PRECISION && src.Precision() == QUDA_SINGLE_PRECISION) {
	blas_bytes += (unsigned long long)dst.Volume()*sizeof(float);
	if (src.Nspin() == 4){
	  Spinor<float4, float4, float4, 6, 0, 0> src_tex(src);
	  Spinor<float4, float4, short4, 6, 1> dst_spinor(dst);
	  CopyCuda<float4, 6, Spinor<float4, float4, short4, 6, 1>,
		   Spinor<float4, float4, float4, 6, 0, 0> >
	    copy(dst_spinor, src_tex, src.Volume());
	  copy.apply(*getBlasStream());	
      } else { //nSpin == 1
	  Spinor<float2, float2, float2, 3, 0, 0> src_tex(src);
	  Spinor<float2, float2, short2, 3, 1> dst_spinor(dst);
	  CopyCuda<float2, 3, Spinor<float2, float2, short2, 3, 1>,
		   Spinor<float2, float2, float2, 3, 0, 0> >
	  copy(dst_spinor, src_tex, src.Volume());
  copy.apply(*getBlasStream());	
}
  } else if (dst.Precision() == QUDA_DOUBLE_PRECISION && src.Precision() == QUDA_HALF_PRECISION) {
	blas_bytes += (unsigned long long)src.Volume()*sizeof(float);
	if (src.Nspin() == 4){
	  Spinor<double2, float4, short4, 12, 0, 0> src_tex(src);
	  Spinor<double2, double2, double2, 12, 1> dst_spinor(dst);
	  CopyCuda<double2, 12, Spinor<double2, double2, double2, 12, 1>,
		   Spinor<double2, float4, short4, 12, 0, 0> >
	    copy(dst_spinor, src_tex, src.Volume());
	  copy.apply(*getBlasStream());	
      } else { //nSpin == 1
	  Spinor<double2, float2, short2, 3, 0, 0> src_tex(src);
	  Spinor<double2, double2, double2, 3, 1> dst_spinor(dst);
	  CopyCuda<double2, 3, Spinor<double2, double2, double2, 3, 1>,
		   Spinor<double2, float2, short2, 3, 0, 0> >
	    copy(dst_spinor, src_tex, src.Volume());
	  copy.apply(*getBlasStream());	
    }
  } else if (dst.Precision() == QUDA_HALF_PRECISION && src.Precision() == QUDA_DOUBLE_PRECISION) {
	blas_bytes += (unsigned long long)dst.Volume()*sizeof(float);
	if (src.Nspin() == 4){
	  Spinor<double2, double2, double2, 12, 0, 0> src_tex(src);
	  Spinor<double2, double4, short4, 12, 1> dst_spinor(dst);
	  CopyCuda<double2, 12, Spinor<double2, double4, short4, 12, 1>,
		   Spinor<double2, double2, double2, 12, 0, 0> >
	    copy(dst_spinor, src_tex, src.Volume());
	  copy.apply(*getBlasStream());	
      } else { //nSpin == 1
	  Spinor<double2, double2, double2, 3, 0, 0> src_tex(src);
	  Spinor<double2, double2, short2, 3, 1> dst_spinor(dst);
	  CopyCuda<double2, 3, Spinor<double2, double2, short2, 3, 1>,
		   Spinor<double2, double2, double2, 3, 0, 0> >
	  copy(dst_spinor, src_tex, src.Volume());
  copy.apply(*getBlasStream());	
}
  } else {
	errorQuda("Invalid precision combination dst=%d and src=%d", dst.Precision(), src.Precision());
      }
      
      /*
      DPCT1001:0: The statement could not be removed.
      */
      /*
      DPCT1000:1: Error handling if-stmt was detected but could not be
      rewritten.
      */
      /*
      DPCT1010:2: SYCL uses exceptions to report errors and does not use the
      error codes. The call was replaced with 0. You need to rewrite this code.
      */
      checkCudaError();
    }
    catch (cl::sycl::exception const &exc) {
        std::cerr << exc.what() << "Exception caught at file:" << __FILE__
                  << ", line:" << __LINE__ << std::endl;
        std::exit(1);
    }

  } // namespace copy

  void copyCuda(cudaColorSpinorField &dst, const cudaColorSpinorField &src) {
    copy::copyCuda(dst, src);
  }
  
} // namespace quda
