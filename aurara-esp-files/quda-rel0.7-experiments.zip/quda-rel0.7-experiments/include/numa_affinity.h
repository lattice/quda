#ifndef __NUMA_AFFINITY_H__
#define __NUMA_AFFINITY_H__

#ifdef __cplusplus
	extern "C" {
#endif
	  
	  int setNumaAffinity(int);
	  
#ifdef __cplusplus 
}
#endif

#endif
