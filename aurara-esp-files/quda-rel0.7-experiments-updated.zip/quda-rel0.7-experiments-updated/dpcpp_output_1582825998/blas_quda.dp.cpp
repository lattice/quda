#include <CL/sycl.hpp>
#include <dpct/dpct.hpp>
#include <stdlib.h>
#include <stdio.h>
#include <cstring> // needed for memset

#include <float_vector.h>

#include <tune_quda.h>
#include <typeinfo>

#include <quda_internal.h>
#include <blas_quda.h>
#include <color_spinor_field.h>
#include <face_quda.h> // this is where the MPI / QMP depdendent code is

#define checkSpinor(a, b)						\
  {									\
    if (a.Precision() != b.Precision())					\
      errorQuda("precisions do not match: %d %d", a.Precision(), b.Precision()); \
    if (a.Length() != b.Length())					\
      errorQuda("lengths do not match: %d %d", a.Length(), b.Length());	\
    if (a.Stride() != b.Stride())					\
      errorQuda("strides do not match: %d %d", a.Stride(), b.Stride());	\
  }

#define checkLength(a, b)						\
  {									\
    if (a.Length() != b.Length())					\
      errorQuda("lengths do not match: %d %d", a.Length(), b.Length());	\
    if (a.Stride() != b.Stride())					\
      errorQuda("strides do not match: %d %d", a.Stride(), b.Stride());	\
  }

namespace quda {

#include <texture.h>

  unsigned long long blas_flops;
  unsigned long long blas_bytes;

  void zeroCuda(cudaColorSpinorField &a) { a.zero(); }

/* DPCT_ORIG   static cudaStream_t *blasStream;*/
  static queue_p *blasStream;

  static struct dpct_type_2e7cb2 {
    const char *vol_str;
    const char *aux_str;
    char aux_tmp[TuneKey::aux_n];
  } blasStrings;

  void initReduce();
  void endReduce();

  void initBlas()
  { 
    blasStream = &streams[Nstream-1];
    initReduce();
  }
  
  void endBlas(void)
  {
    endReduce();
  }
    
/* DPCT_ORIG   cudaStream_t* getBlasStream() { return blasStream; }*/
  queue_p *getBlasStream() { return blasStream; }

#include "blas_core.h"
#include "blas_mixed_core.h"

using queue_p = cl::sycl::queue *;

  /**
     Functor to perform the operation y = a*x + b*y
  */
  template <typename Float2, typename FloatN>
  struct axpby {
    const Float2 a;
    const Float2 b;
    axpby(const Float2 &a, const Float2 &b, const Float2 &c) : a(a), b(b) { ; }
/* DPCT_ORIG     __device__ void operator()(const FloatN &x, FloatN &y, const
 * FloatN &z, const FloatN &w) { y = a.x*x + b.x*y; }*/
    void operator()(const FloatN &x, FloatN &y, const FloatN &z,
                    const FloatN &w) { y = static_cast<const double>(a.x()) * x +
        static_cast<const double>(b.x()) * y; }
    static int streams() { return 3; } //! total number of input and output streams
    static int flops() { return 3; } //! flops per element
  };

  void axpbyCuda(const double &a, cudaColorSpinorField &x, const double &b, cudaColorSpinorField &y) {
/* DPCT_ORIG     blasCuda<axpby,0,1,0,0>(make_double2(a, 0.0), make_double2(b,
 * 0.0), make_double2(0.0, 0.0),*/
    blasCuda<axpby, 0, 1, 0, 0>(cl::sycl::double2(a, 0.0),
                                cl::sycl::double2(b, 0.0),
                                cl::sycl::double2(0.0, 0.0), x, y, x, x);
  }

  /**
     Functor to perform the operation y += x
  */
  template <typename Float2, typename FloatN>
  struct xpy {
    xpy(const Float2 &a, const Float2 &b, const Float2 &c) { ; }
/* DPCT_ORIG     __device__ void operator()(const FloatN &x, FloatN &y, const
 * FloatN &z, const FloatN &w) { y += x ; }*/
    void operator()(const FloatN &x, FloatN &y, const FloatN &z,
                    const FloatN &w) { y += x ; }
    static int streams() { return 3; } //! total number of input and output streams
    static int flops() { return 1; } //! flops per element
  };

  void xpyCuda(cudaColorSpinorField &x, cudaColorSpinorField &y) {
/* DPCT_ORIG     blasCuda<xpy,0,1,0,0>(make_double2(1.0, 0.0), make_double2(1.0,
 * 0.0), make_double2(0.0, 0.0), */
    blasCuda<xpy, 0, 1, 0, 0>(cl::sycl::double2(1.0, 0.0),
                              cl::sycl::double2(1.0, 0.0),
                              cl::sycl::double2(0.0, 0.0), x, y, x, x);
  }

  /**
     Functor to perform the operation y += a*x
  */
  template <typename Float2, typename FloatN>
  struct axpy {
    const Float2 a;
    axpy(const Float2 &a, const Float2 &b, const Float2 &c) : a(a) { ; }
/* DPCT_ORIG     __device__ void operator()(const FloatN &x, FloatN &y, const
 * FloatN &z, const FloatN &w) { y = a.x*x + y; }*/
    void operator()(const FloatN &x, FloatN &y, const FloatN &z,
                    const FloatN &w) { y = static_cast<const double>(a.x()) * x + y; }
    static int streams() { return 3; } //! total number of input and output streams
    static int flops() { return 2; } //! flops per element
  };

  void axpyCuda(const double &a, cudaColorSpinorField &x, cudaColorSpinorField &y) {
    if (x.Precision() != y.Precision()) {
      // call hacked mixed precision kernel
/* DPCT_ORIG       mixed::blasCuda<axpy,0,1,0,0>(make_double2(a,0.0),
 * make_double2(1.0,0.0), make_double2(0.0,0.0),*/
      mixed::blasCuda<axpy, 0, 1, 0, 0>(
          cl::sycl::double2(a, 0.0), cl::sycl::double2(1.0, 0.0),
          cl::sycl::double2(0.0, 0.0), x, y, x, x);
    } else {
/* DPCT_ORIG       blasCuda<axpy,0,1,0,0>(make_double2(a, 0.0),
 * make_double2(1.0, 0.0), make_double2(0.0, 0.0), */
      blasCuda<axpy, 0, 1, 0, 0>(cl::sycl::double2(a, 0.0),
                                 cl::sycl::double2(1.0, 0.0),
                                 cl::sycl::double2(0.0, 0.0), x, y, x, x);
    }
  }

  /**
     Functor to perform the operation y = x + a*y
  */
  template <typename Float2, typename FloatN>
  struct xpay {
    const Float2 a;
    xpay(const Float2 &a, const Float2 &b, const Float2 &c) : a(a) { ; }
/* DPCT_ORIG     __device__ void operator()(const FloatN &x, FloatN &y, const
 * FloatN &z, const FloatN &w) { y = x + a.x*y; }*/
    void operator()(const FloatN &x, FloatN &y, const FloatN &z,
                    const FloatN &w) { y = x + static_cast<const double>(a.x()) * y; }
    static int streams() { return 3; } //! total number of input and output streams
    static int flops() { return 2; } //! flops per element
  };

  void xpayCuda(cudaColorSpinorField &x, const double &a, cudaColorSpinorField &y) {
/* DPCT_ORIG     blasCuda<xpay,0,1,0,0>(make_double2(a,0.0), make_double2(0.0,
 * 0.0), make_double2(0.0, 0.0),*/
    blasCuda<xpay, 0, 1, 0, 0>(cl::sycl::double2(a, 0.0),
                               cl::sycl::double2(0.0, 0.0),
                               cl::sycl::double2(0.0, 0.0), x, y, x, x);
  }

  /**
     Functor to perform the operation y -= x;
  */
  template <typename Float2, typename FloatN>
  struct mxpy {
    mxpy(const Float2 &a, const Float2 &b, const Float2 &c) { ; }
/* DPCT_ORIG     __device__ void operator()(const FloatN &x, FloatN &y, const
 * FloatN &z, const FloatN &w) { y -= x; }*/
    void operator()(const FloatN &x, FloatN &y, const FloatN &z,
                    const FloatN &w) { y -= x; }
    static int streams() { return 3; } //! total number of input and output streams
    static int flops() { return 1; } //! flops per element
  };

  void mxpyCuda(cudaColorSpinorField &x, cudaColorSpinorField &y) {
/* DPCT_ORIG     blasCuda<mxpy,0,1,0,0>(make_double2(1.0, 0.0),
 * make_double2(1.0, 0.0), */
    blasCuda<mxpy, 0, 1, 0, 0>(cl::sycl::double2(1.0, 0.0),
                               cl::sycl::double2(1.0, 0.0),
                               /* DPCT_ORIG
                                  make_double2(0.0, 0.0), x, y, x, x);*/
                               cl::sycl::double2(0.0, 0.0), x, y, x, x);
  }

  /**
     Functor to perform the operation x *= a
  */
  template <typename Float2, typename FloatN>
  struct ax {
    const Float2 a;
    ax(const Float2 &a, const Float2 &b, const Float2 &c) : a(a) { ; }
/* DPCT_ORIG     __device__ void operator()(FloatN &x, const FloatN &y, const
 * FloatN &z, const FloatN &w) { x *= a.x; }*/
    void operator()(FloatN &x, const FloatN &y, const FloatN &z,
                    const FloatN &w) { x *= static_cast<const double>(a.x()); }
    static int streams() { return 2; } //! total number of input and output streams
    static int flops() { return 1; } //! flops per element
  };

  void axCuda(const double &a, cudaColorSpinorField &x) {
/* DPCT_ORIG     blasCuda<ax,1,0,0,0>(make_double2(a, 0.0), make_double2(0.0,
 * 0.0), */
    blasCuda<ax, 1, 0, 0, 0>(
        cl::sycl::double2(a, 0.0), cl::sycl::double2(0.0, 0.0),
        /* DPCT_ORIG 			 make_double2(0.0, 0.0), x, x, x, x);*/
        cl::sycl::double2(0.0, 0.0), x, x, x, x);
  }

  /**
     Functor to perform the operation y += a * x  (complex-valued)
  */

/* DPCT_ORIG   __device__ void caxpy_(const float2 &a, const float4 &x, float4
 * &y) {*/
  void caxpy_(const cl::sycl::float2 &a, const cl::sycl::float4 &x,
              cl::sycl::float4 &y) {
/* DPCT_ORIG     y.x += a.x*x.x; y.x -= a.y*x.y;*/
    y.x() += static_cast<const float>(a.x()) * static_cast<const float>(x.x()); y.x() -= static_cast<const float>(a.y()) * static_cast<const float>(x.y());
/* DPCT_ORIG     y.y += a.y*x.x; y.y += a.x*x.y;*/
    y.y() += static_cast<const float>(a.y()) * static_cast<const float>(x.x()); y.y() += static_cast<const float>(a.x()) * static_cast<const float>(x.y());
/* DPCT_ORIG     y.z += a.x*x.z; y.z -= a.y*x.w;*/
    y.z() += static_cast<const float>(a.x()) * static_cast<const float>(x.z()); y.z() -= static_cast<const float>(a.y()) * static_cast<const float>(x.w());
/* DPCT_ORIG     y.w += a.y*x.z; y.w += a.x*x.w;*/
    y.w() += static_cast<const float>(a.y()) * static_cast<const float>(x.z()); y.w() += static_cast<const float>(a.x()) * static_cast<const float>(x.w());
  }

/* DPCT_ORIG   __device__ void caxpy_(const float2 &a, const float2 &x, float2
 * &y) {*/
  void caxpy_(const cl::sycl::float2 &a, const cl::sycl::float2 &x,
              cl::sycl::float2 &y) {
/* DPCT_ORIG     y.x += a.x*x.x; y.x -= a.y*x.y;*/
    y.x() += static_cast<const float>(a.x()) * static_cast<const float>(x.x()); y.x() -= static_cast<const float>(a.y()) * static_cast<const float>(x.y());
/* DPCT_ORIG     y.y += a.y*x.x; y.y += a.x*x.y;*/
    y.y() += static_cast<const float>(a.y()) * static_cast<const float>(x.x()); y.y() += static_cast<const float>(a.x()) * static_cast<const float>(x.y());
  }

/* DPCT_ORIG   __device__ void caxpy_(const double2 &a, const double2 &x,
 * double2 &y) {*/
  void caxpy_(const cl::sycl::double2 &a, const cl::sycl::double2 &x,
              cl::sycl::double2 &y) {
/* DPCT_ORIG     y.x += a.x*x.x; y.x -= a.y*x.y;*/
    y.x() +=
        static_cast<const double>(a.x()) * static_cast<const double>(x.x()); y.x() -=
        static_cast<const double>(a.y()) * static_cast<const double>(x.y());
/* DPCT_ORIG     y.y += a.y*x.x; y.y += a.x*x.y;*/
    y.y() +=
        static_cast<const double>(a.y()) * static_cast<const double>(x.x()); y.y() +=
        static_cast<const double>(a.x()) * static_cast<const double>(x.y());
  }

  template <typename Float2, typename FloatN>
  struct caxpy {
    const Float2 a;
    caxpy(const Float2 &a, const Float2 &b, const Float2 &c) : a(a) { ; }
/* DPCT_ORIG     __device__ void operator()(const FloatN &x, FloatN &y, const
 * FloatN &z, const FloatN &w) */
    void operator()(const FloatN &x, FloatN &y, const FloatN &z,
                    const FloatN &w)
    { caxpy_(a, x, y); }
    static int streams() { return 3; } //! total number of input and output streams
    static int flops() { return 4; } //! flops per element
  };

  void caxpyCuda(const Complex &a, cudaColorSpinorField &x, cudaColorSpinorField &y) {
/* DPCT_ORIG     blasCuda<caxpy,0,1,0,0>(make_double2(REAL(a), IMAG(a)), */
    blasCuda<caxpy, 0, 1, 0, 0>(
        cl::sycl::double2(REAL(a), IMAG(a)),
        /* DPCT_ORIG 			    make_double2(0.0, 0.0), */
        cl::sycl::double2(0.0, 0.0),
        /* DPCT_ORIG 			    make_double2(0.0, 0.0), x, y, x,
           x);*/
        cl::sycl::double2(0.0, 0.0), x, y, x, x);
  }

  /**
     Functor to perform the operation y = a*x + b*y  (complex-valued)
  */

/* DPCT_ORIG   __device__ void caxpby_(const float2 &a, const float4 &x, const
 * float2 &b, float4 &y)					*/
  void caxpby_(const cl::sycl::float2 &a, const cl::sycl::float4 &x,
               const cl::sycl::float2 &b, cl::sycl::float4 &y)					
/* DPCT_ORIG   { float4 yy;
 */
  { cl::sycl::float4 yy;								
/* DPCT_ORIG     yy.x = a.x*x.x; yy.x -= a.y*x.y; yy.x += b.x*y.x; yy.x -=
 * b.y*y.y;	*/
    yy.x() = static_cast<const float>(a.x()) * static_cast<const float>(x.x()); yy.x() -= static_cast<const float>(a.y()) * static_cast<const float>(x.y()); yy.x() += static_cast<const float>(b.x()) * static_cast<float>(y.x()); yy.x() -= static_cast<const float>(b.y()) * static_cast<float>(y.y());	
/* DPCT_ORIG     yy.y = a.y*x.x; yy.y += a.x*x.y; yy.y += b.y*y.x; yy.y +=
 * b.x*y.y;	*/
    yy.y() = static_cast<const float>(a.y()) * static_cast<const float>(x.x()); yy.y() += static_cast<const float>(a.x()) * static_cast<const float>(x.y()); yy.y() += static_cast<const float>(b.y()) * static_cast<float>(y.x()); yy.y() += static_cast<const float>(b.x()) * static_cast<float>(y.y());	
/* DPCT_ORIG     yy.z = a.x*x.z; yy.z -= a.y*x.w; yy.z += b.x*y.z; yy.z -=
 * b.y*y.w;	*/
    yy.z() = static_cast<const float>(a.x()) * static_cast<const float>(x.z()); yy.z() -= static_cast<const float>(a.y()) * static_cast<const float>(x.w()); yy.z() += static_cast<const float>(b.x()) * static_cast<float>(y.z()); yy.z() -= static_cast<const float>(b.y()) * static_cast<float>(y.w());	
/* DPCT_ORIG     yy.w = a.y*x.z; yy.w += a.x*x.w; yy.w += b.y*y.z; yy.w +=
 * b.x*y.w;	*/
    yy.w() = static_cast<const float>(a.y()) * static_cast<const float>(x.z()); yy.w() += static_cast<const float>(a.x()) * static_cast<const float>(x.w()); yy.w() += static_cast<const float>(b.y()) * static_cast<float>(y.z()); yy.w() += static_cast<const float>(b.x()) * static_cast<float>(y.w());
    y = yy; }

/* DPCT_ORIG   __device__ void caxpby_(const float2 &a, const float2 &x, const
 * float2 &b, float2 &y)*/
  void caxpby_(const cl::sycl::float2 &a, const cl::sycl::float2 &x,
               const cl::sycl::float2 &b, cl::sycl::float2 &y)
/* DPCT_ORIG   { float2 yy;
 */
  { cl::sycl::float2 yy;								
/* DPCT_ORIG     yy.x = a.x*x.x; yy.x -= a.y*x.y; yy.x += b.x*y.x; yy.x -=
 * b.y*y.y;	*/
    yy.x() = static_cast<const float>(a.x()) * static_cast<const float>(x.x()); yy.x() -= static_cast<const float>(a.y()) * static_cast<const float>(x.y()); yy.x() += static_cast<const float>(b.x()) * static_cast<float>(y.x()); yy.x() -= static_cast<const float>(b.y()) * static_cast<float>(y.y());	
/* DPCT_ORIG     yy.y = a.y*x.x; yy.y += a.x*x.y; yy.y += b.y*y.x; yy.y +=
 * b.x*y.y;	*/
    yy.y() = static_cast<const float>(a.y()) * static_cast<const float>(x.x()); yy.y() += static_cast<const float>(a.x()) * static_cast<const float>(x.y()); yy.y() += static_cast<const float>(b.y()) * static_cast<float>(y.x()); yy.y() += static_cast<const float>(b.x()) * static_cast<float>(y.y());
    y = yy; }

/* DPCT_ORIG   __device__ void caxpby_(const double2 &a, const double2 &x, const
 * double2 &b, double2 &y)				 */
  void caxpby_(const cl::sycl::double2 &a, const cl::sycl::double2 &x,
               const cl::sycl::double2 &b, cl::sycl::double2 &y)				 
/* DPCT_ORIG   { double2 yy;
 */
  { cl::sycl::double2 yy;								
/* DPCT_ORIG     yy.x = a.x*x.x; yy.x -= a.y*x.y; yy.x += b.x*y.x; yy.x -=
 * b.y*y.y;	*/
    yy.x() =
        static_cast<const double>(a.x()) * static_cast<const double>(x.x()); yy.x() -=
        static_cast<const double>(a.y()) * static_cast<const double>(x.y()); yy.x() += static_cast<const double>(b.x()) * static_cast<double>(y.x()); yy.x() -= static_cast<const double>(b.y()) * static_cast<double>(y.y());	
/* DPCT_ORIG     yy.y = a.y*x.x; yy.y += a.x*x.y; yy.y += b.y*y.x; yy.y +=
 * b.x*y.y;	*/
    yy.y() =
        static_cast<const double>(a.y()) * static_cast<const double>(x.x()); yy.y() +=
        static_cast<const double>(a.x()) * static_cast<const double>(x.y()); yy.y() += static_cast<const double>(b.y()) * static_cast<double>(y.x()); yy.y() += static_cast<const double>(b.x()) * static_cast<double>(y.y());
    y = yy; }

  template <typename Float2, typename FloatN>
  struct caxpby {
    const Float2 a;
    const Float2 b;
    caxpby(const Float2 &a, const Float2 &b, const Float2 &c) : a(a), b(b) { ; }
/* DPCT_ORIG     __device__ void operator()(const FloatN &x, FloatN &y, const
 * FloatN &z, const FloatN &w) { caxpby_(a, x, b, y); }*/
    void operator()(const FloatN &x, FloatN &y, const FloatN &z,
                    const FloatN &w) { caxpby_(a, x, b, y); }
    static int streams() { return 3; } //! total number of input and output streams
    static int flops() { return 7; } //! flops per element
  };

  void caxpbyCuda(const Complex &a, cudaColorSpinorField &x, const Complex &b, cudaColorSpinorField &y) {
/* DPCT_ORIG     blasCuda<caxpby,0,1,0,0>(make_double2(REAL(a),IMAG(a)),
 * make_double2(REAL(b), IMAG(b)), */
    blasCuda<caxpby, 0, 1, 0, 0>(cl::sycl::double2(REAL(a), IMAG(a)),
                                 cl::sycl::double2(REAL(b), IMAG(b)),
                                 /* DPCT_ORIG
                                    make_double2(0.0, 0.0), x, y, x, x);*/
                                 cl::sycl::double2(0.0, 0.0), x, y, x, x);
  }

  /**
     Functor to performs the operation z[i] = x[i] + a*y[i] + b*z[i]
  */

/* DPCT_ORIG   __device__ void cxpaypbz_(const float4 &x, const float2 &a, const
 * float4 &y, const float2 &b, float4 &z) {*/
  void cxpaypbz_(const cl::sycl::float4 &x, const cl::sycl::float2 &a,
                 const cl::sycl::float4 &y, const cl::sycl::float2 &b,
                 cl::sycl::float4 &z) {
/* DPCT_ORIG     float4 zz;*/
    cl::sycl::float4 zz;
/* DPCT_ORIG     zz.x = x.x + a.x*y.x; zz.x -= a.y*y.y; zz.x += b.x*z.x; zz.x -=
 * b.y*z.y;*/
    zz.x() = static_cast<const float>(x.x()) +
             static_cast<const float>(a.x()) * static_cast<const float>(y.x()); zz.x() -= static_cast<const float>(a.y()) * static_cast<const float>(y.y()); zz.x() += static_cast<const float>(b.x()) * static_cast<float>(z.x()); zz.x() -= static_cast<const float>(b.y()) * static_cast<float>(z.y());
/* DPCT_ORIG     zz.y = x.y + a.y*y.x; zz.y += a.x*y.y; zz.y += b.y*z.x; zz.y +=
 * b.x*z.y;*/
    zz.y() = static_cast<const float>(x.y()) +
             static_cast<const float>(a.y()) * static_cast<const float>(y.x()); zz.y() += static_cast<const float>(a.x()) * static_cast<const float>(y.y()); zz.y() += static_cast<const float>(b.y()) * static_cast<float>(z.x()); zz.y() += static_cast<const float>(b.x()) * static_cast<float>(z.y());
/* DPCT_ORIG     zz.z = x.z + a.x*y.z; zz.z -= a.y*y.w; zz.z += b.x*z.z; zz.z -=
 * b.y*z.w;*/
    zz.z() = static_cast<const float>(x.z()) +
             static_cast<const float>(a.x()) * static_cast<const float>(y.z()); zz.z() -= static_cast<const float>(a.y()) * static_cast<const float>(y.w()); zz.z() += static_cast<const float>(b.x()) * static_cast<float>(z.z()); zz.z() -= static_cast<const float>(b.y()) * static_cast<float>(z.w());
/* DPCT_ORIG     zz.w = x.w + a.y*y.z; zz.w += a.x*y.w; zz.w += b.y*z.z; zz.w +=
 * b.x*z.w;*/
    zz.w() = static_cast<const float>(x.w()) +
             static_cast<const float>(a.y()) * static_cast<const float>(y.z()); zz.w() += static_cast<const float>(a.x()) * static_cast<const float>(y.w()); zz.w() += static_cast<const float>(b.y()) * static_cast<float>(z.z()); zz.w() += static_cast<const float>(b.x()) * static_cast<float>(z.w());
    z = zz;
  }

/* DPCT_ORIG   __device__ void cxpaypbz_(const float2 &x, const float2 &a, const
 * float2 &y, const float2 &b, float2 &z) {*/
  void cxpaypbz_(const cl::sycl::float2 &x, const cl::sycl::float2 &a,
                 const cl::sycl::float2 &y, const cl::sycl::float2 &b,
                 cl::sycl::float2 &z) {
/* DPCT_ORIG     float2 zz;*/
    cl::sycl::float2 zz;
/* DPCT_ORIG     zz.x = x.x + a.x*y.x; zz.x -= a.y*y.y; zz.x += b.x*z.x; zz.x -=
 * b.y*z.y;*/
    zz.x() = static_cast<const float>(x.x()) +
             static_cast<const float>(a.x()) * static_cast<const float>(y.x()); zz.x() -= static_cast<const float>(a.y()) * static_cast<const float>(y.y()); zz.x() += static_cast<const float>(b.x()) * static_cast<float>(z.x()); zz.x() -= static_cast<const float>(b.y()) * static_cast<float>(z.y());
/* DPCT_ORIG     zz.y = x.y + a.y*y.x; zz.y += a.x*y.y; zz.y += b.y*z.x; zz.y +=
 * b.x*z.y;*/
    zz.y() = static_cast<const float>(x.y()) +
             static_cast<const float>(a.y()) * static_cast<const float>(y.x()); zz.y() += static_cast<const float>(a.x()) * static_cast<const float>(y.y()); zz.y() += static_cast<const float>(b.y()) * static_cast<float>(z.x()); zz.y() += static_cast<const float>(b.x()) * static_cast<float>(z.y());
    z = zz;
  }

/* DPCT_ORIG   __device__ void cxpaypbz_(const double2 &x, const double2 &a,
 * const double2 &y, const double2 &b, double2 &z) {*/
  void cxpaypbz_(const cl::sycl::double2 &x, const cl::sycl::double2 &a,
                 const cl::sycl::double2 &y, const cl::sycl::double2 &b,
                 cl::sycl::double2 &z) {
/* DPCT_ORIG     double2 zz;*/
    cl::sycl::double2 zz;
/* DPCT_ORIG     zz.x = x.x + a.x*y.x; zz.x -= a.y*y.y; zz.x += b.x*z.x; zz.x -=
 * b.y*z.y;*/
    zz.x() =
        static_cast<const double>(x.x()) +
        static_cast<const double>(a.x()) * static_cast<const double>(y.x()); zz.x() -=
        static_cast<const double>(a.y()) * static_cast<const double>(y.y()); zz.x() += static_cast<const double>(b.x()) * static_cast<double>(z.x()); zz.x() -= static_cast<const double>(b.y()) * static_cast<double>(z.y());
/* DPCT_ORIG     zz.y = x.y + a.y*y.x; zz.y += a.x*y.y; zz.y += b.y*z.x; zz.y +=
 * b.x*z.y;*/
    zz.y() =
        static_cast<const double>(x.y()) +
        static_cast<const double>(a.y()) * static_cast<const double>(y.x()); zz.y() +=
        static_cast<const double>(a.x()) * static_cast<const double>(y.y()); zz.y() += static_cast<const double>(b.y()) * static_cast<double>(z.x()); zz.y() += static_cast<const double>(b.x()) * static_cast<double>(z.y());
    z = zz;
  }

  template <typename Float2, typename FloatN>
  struct cxpaypbz {
    const Float2 a;
    const Float2 b;
    cxpaypbz(const Float2 &a, const Float2 &b, const Float2 &c) : a(a), b(b) { ; }
/* DPCT_ORIG     __device__ void operator()(const FloatN &x, const FloatN &y,
 * FloatN &z, FloatN &w) */
    void operator()(const FloatN &x, const FloatN &y, FloatN &z, FloatN &w)
    { cxpaypbz_(x, a, y, b, z); }
    static int streams() { return 4; } //! total number of input and output streams
    static int flops() { return 8; } //! flops per element
  };

  void cxpaypbzCuda(cudaColorSpinorField &x, const Complex &a, cudaColorSpinorField &y, 
		    const Complex &b, cudaColorSpinorField &z) {
/* DPCT_ORIG     blasCuda<cxpaypbz,0,0,1,0>(make_double2(REAL(a),IMAG(a)),
 * make_double2(REAL(b), IMAG(b)), */
    blasCuda<cxpaypbz, 0, 0, 1, 0>(cl::sycl::double2(REAL(a), IMAG(a)),
                                   cl::sycl::double2(REAL(b), IMAG(b)),
                                   /* DPCT_ORIG
                                      make_double2(0.0, 0.0), x, y, z, z);*/
                                   cl::sycl::double2(0.0, 0.0), x, y, z, z);
  }

  /**
     Functor performing the operations: y[i] = a*x[i] + y[i]; x[i] = b*z[i] + c*x[i]
  */
  template <typename Float2, typename FloatN>
  struct axpyBzpcx {
    const Float2 a;
    const Float2 b;
    const Float2 c;
    axpyBzpcx(const Float2 &a, const Float2 &b, const Float2 &c) : a(a), b(b), c(c) { ; }
/* DPCT_ORIG     __device__ void operator()(FloatN &x, FloatN &y, const FloatN
 * &z, const FloatN &w)*/
    void operator()(FloatN &x, FloatN &y, const FloatN &z, const FloatN &w)
/* DPCT_ORIG     { y += a.x*x; x = b.x*z + c.x*x; }*/
    { y += static_cast<const double>(a.x()) * x; x = static_cast<const double>(b.x()) * z +
        static_cast<const double>(c.x()) * x; }
    static int streams() { return 5; } //! total number of input and output streams
    static int flops() { return 10; } //! flops per element
  };

  void axpyBzpcxCuda(const double &a, cudaColorSpinorField& x, cudaColorSpinorField& y, const double &b, 
		     cudaColorSpinorField& z, const double &c) {
    if (x.Precision() != y.Precision()) {
      // call hacked mixed precision kernel
/* DPCT_ORIG       mixed::blasCuda<axpyBzpcx,1,1,0,0>(make_double2(a,0.0),
 * make_double2(b,0.0), */
      mixed::blasCuda<axpyBzpcx, 1, 1, 0, 0>(
          cl::sycl::double2(a, 0.0), cl::sycl::double2(b, 0.0),
          /* DPCT_ORIG 					 make_double2(c,0.0),	x, y, z,
             x);*/
          cl::sycl::double2(c, 0.0), x, y, z, x);
    } else {
      // swap arguments around 
/* DPCT_ORIG       blasCuda<axpyBzpcx,1,1,0,0>(make_double2(a,0.0),
 * make_double2(b,0.0), */
      blasCuda<axpyBzpcx, 1, 1, 0, 0>(cl::sycl::double2(a, 0.0),
                                      cl::sycl::double2(b, 0.0),
                                      /* DPCT_ORIG
                                         make_double2(c,0.0), x, y, z, x);*/
                                      cl::sycl::double2(c, 0.0), x, y, z, x);
    }
  }

  /**
     Functor performing the operations: y[i] = a*x[i] + y[i]; x[i] = z[i] + b*x[i]
  */
  template <typename Float2, typename FloatN>
  struct axpyZpbx {
    const Float2 a;
    const Float2 b;
    axpyZpbx(const Float2 &a, const Float2 &b, const Float2 &c) : a(a), b(b) { ; }
/* DPCT_ORIG     __device__ void operator()(FloatN &x, FloatN &y, const FloatN
 * &z, const FloatN &w)*/
    void operator()(FloatN &x, FloatN &y, const FloatN &z, const FloatN &w)
/* DPCT_ORIG     { y += a.x*x; x = z + b.x*x; }*/
    { y += static_cast<const double>(a.x()) * x; x = z + static_cast<const double>(b.x()) * x; }
    static int streams() { return 5; } //! total number of input and output streams
    static int flops() { return 8; } //! flops per element
  };

  void axpyZpbxCuda(const double &a, cudaColorSpinorField& x, cudaColorSpinorField& y,
		    cudaColorSpinorField& z, const double &b) {
    if (x.Precision() != y.Precision()) {
      // call hacked mixed precision kernel
/* DPCT_ORIG       mixed::blasCuda<axpyZpbx,1,1,0,0>(make_double2(a,0.0),
 * make_double2(b,0.0), make_double2(0.0,0.0),*/
      mixed::blasCuda<axpyZpbx, 1, 1, 0, 0>(
          cl::sycl::double2(a, 0.0), cl::sycl::double2(b, 0.0),
          cl::sycl::double2(0.0, 0.0), x, y, z, x);
    } else {
      // swap arguments around 
/* DPCT_ORIG       blasCuda<axpyZpbx,1,1,0,0>(make_double2(a,0.0),
 * make_double2(b,0.0), make_double2(0.0,0.0),*/
      blasCuda<axpyZpbx, 1, 1, 0, 0>(cl::sycl::double2(a, 0.0),
                                     cl::sycl::double2(b, 0.0),
                                     cl::sycl::double2(0.0, 0.0), x, y, z, x);
    }
  }

  /**
     Functor performing the operations z[i] = a*x[i] + b*y[i] + z[i] and y[i] -= b*w[i]
  */
  template <typename Float2, typename FloatN>
  struct caxpbypzYmbw {
    const Float2 a;
    const Float2 b;
    caxpbypzYmbw(const Float2 &a, const Float2 &b, const Float2 &c) : a(a), b(b) { ; }
/* DPCT_ORIG     __device__ void operator()(const FloatN &x, FloatN &y, FloatN
 * &z, const FloatN &w)*/
    void operator()(const FloatN &x, FloatN &y, FloatN &z, const FloatN &w)
    { caxpy_(a, x, z); caxpy_(b, y, z); caxpy_(-b, w, y); }

    static int streams() { return 6; } //! total number of input and output streams
    static int flops() { return 12; } //! flops per element
  };

  void caxpbypzYmbwCuda(const Complex &a, cudaColorSpinorField &x, const Complex &b, 
			cudaColorSpinorField &y, cudaColorSpinorField &z, cudaColorSpinorField &w) {
/* DPCT_ORIG     blasCuda<caxpbypzYmbw,0,1,1,0>(make_double2(REAL(a),IMAG(a)),
 * make_double2(REAL(b),IMAG(b)), */
    blasCuda<caxpbypzYmbw, 0, 1, 1, 0>(cl::sycl::double2(REAL(a), IMAG(a)),
                                       cl::sycl::double2(REAL(b), IMAG(b)),
                                       /* DPCT_ORIG
                                          make_double2(0.0,0.0), x, y, z, w);*/
                                       cl::sycl::double2(0.0, 0.0), x, y, z, w);
  }

  /**
     Functor performing the operation y[i] += a*b*x[i], x[i] *= a
  */
  template <typename Float2, typename FloatN>
  struct cabxpyAx {
    const Float2 a;
    const Float2 b;
    cabxpyAx(const Float2 &a, const Float2 &b, const Float2 &c) : a(a), b(b) { ; }
/* DPCT_ORIG     __device__ void operator()(FloatN &x, FloatN &y, const FloatN
 * &z, const FloatN &w) */
    void operator()(FloatN &x, FloatN &y, const FloatN &z, const FloatN &w) 
/* DPCT_ORIG     { x *= a.x; caxpy_(b, x, y); }*/
    { x *= static_cast<const double>(a.x()); caxpy_(b, x, y); }
    static int streams() { return 4; } //! total number of input and output streams
    static int flops() { return 5; } //! flops per element
  };

  void cabxpyAxCuda(const double &a, const Complex &b, 
		    cudaColorSpinorField &x, cudaColorSpinorField &y) {
    // swap arguments around 
/* DPCT_ORIG     blasCuda<cabxpyAx,1,1,0,0>(make_double2(a,0.0),
 * make_double2(REAL(b),IMAG(b)), */
    blasCuda<cabxpyAx, 1, 1, 0, 0>(cl::sycl::double2(a, 0.0),
                                   cl::sycl::double2(REAL(b), IMAG(b)),
                                   /* DPCT_ORIG
                                      make_double2(0.0,0.0), x, y, x, x);*/
                                   cl::sycl::double2(0.0, 0.0), x, y, x, x);
  }

  /**
     Functor performing the operation z[i] = a*x[i] + b*y[i] + z[i]
  */
  template <typename Float2, typename FloatN>
  struct caxpbypz {
    const Float2 a;
    const Float2 b;
    caxpbypz(const Float2 &a, const Float2 &b, const Float2 &c) : a(a), b(b) { ; }
/* DPCT_ORIG     __device__ void operator()(const FloatN &x, const FloatN &y,
 * FloatN &z, const FloatN &w) */
    void operator()(const FloatN &x, const FloatN &y, FloatN &z,
                    const FloatN &w)
    { caxpy_(a, x, z); caxpy_(b, y, z); }
    static int streams() { return 4; } //! total number of input and output streams
    static int flops() { return 5; } //! flops per element
  };

  void caxpbypzCuda(const Complex &a, cudaColorSpinorField &x, const Complex &b, 
		    cudaColorSpinorField &y, cudaColorSpinorField &z) {
/* DPCT_ORIG     blasCuda<caxpbypz,0,0,1,0>(make_double2(REAL(a),IMAG(a)),
 * make_double2(REAL(b),IMAG(b)), */
    blasCuda<caxpbypz, 0, 0, 1, 0>(cl::sycl::double2(REAL(a), IMAG(a)),
                                   cl::sycl::double2(REAL(b), IMAG(b)),
                                   /* DPCT_ORIG
                                      make_double2(0.0,0.0), x, y, z, z);*/
                                   cl::sycl::double2(0.0, 0.0), x, y, z, z);
  }

  /**
     Functor Performing the operation w[i] = a*x[i] + b*y[i] + c*z[i] + w[i]
  */
  template <typename Float2, typename FloatN>
  struct caxpbypczpw {
    const Float2 a;
    const Float2 b;
    const Float2 c;
    caxpbypczpw(const Float2 &a, const Float2 &b, const Float2 &c) : a(a), b(b), c(c) { ; }
/* DPCT_ORIG     __device__ void operator()(const FloatN &x, const FloatN &y,
 * const FloatN &z, FloatN &w) */
    void operator()(const FloatN &x, const FloatN &y, const FloatN &z,
                    FloatN &w)
    { caxpy_(a, x, w); caxpy_(b, y, w); caxpy_(c, z, w); }

    static int streams() { return 4; } //! total number of input and output streams
    static int flops() { return 5; } //! flops per element
  };

  void caxpbypczpwCuda(const Complex &a, cudaColorSpinorField &x, const Complex &b, 
		       cudaColorSpinorField &y, const Complex &c, cudaColorSpinorField &z, 
		       cudaColorSpinorField &w) {
/* DPCT_ORIG     blasCuda<caxpbypczpw,0,0,0,1>(make_double2(REAL(a),IMAG(a)),
 * make_double2(REAL(b),IMAG(b)), */
    blasCuda<caxpbypczpw, 0, 0, 0, 1>(
        cl::sycl::double2(REAL(a), IMAG(a)),
        cl::sycl::double2(REAL(b), IMAG(b)),
        /* DPCT_ORIG 				  make_double2(REAL(c),IMAG(c)), x,
           y, z, w);*/
        cl::sycl::double2(REAL(c), IMAG(c)), x, y, z, w);
  }

  /**
     double caxpyXmazCuda(c a, V x, V y, V z){}
   
     First performs the operation y[i] += a*x[i]
     Second performs the operator x[i] -= a*z[i]
  */
  template <typename Float2, typename FloatN>
  struct caxpyxmaz {
    Float2 a;
    caxpyxmaz(const Float2 &a, const Float2 &b, const Float2 &c) : a(a) { ; }
/* DPCT_ORIG     __device__ void operator()(FloatN &x, FloatN &y, const FloatN
 * &z, const FloatN &w) */
    void operator()(FloatN &x, FloatN &y, const FloatN &z, const FloatN &w)
    { caxpy_(a, x, y); caxpy_(-a, z, x); }
    static int streams() { return 5; } //! total number of input and output streams
    static int flops() { return 8; } //! flops per element
  };

  void caxpyXmazCuda(const Complex &a, cudaColorSpinorField &x, 
		     cudaColorSpinorField &y, cudaColorSpinorField &z) {
/* DPCT_ORIG     blasCuda<caxpyxmaz,1,1,0,0>(make_double2(REAL(a), IMAG(a)),
 * make_double2(0.0, 0.0), */
    blasCuda<caxpyxmaz, 1, 1, 0, 0>(cl::sycl::double2(REAL(a), IMAG(a)),
                                    cl::sycl::double2(0.0, 0.0),
                                    /* DPCT_ORIG 				make_double2(0.0, 0.0),
                                       x, y, z, x);*/
                                    cl::sycl::double2(0.0, 0.0), x, y, z, x);
  }

  /**
     double tripleCGUpdate(d a, d b, V x, V y, V z, V w){}
   
     First performs the operation y[i] = y[i] - a*x[i] 
     Second performs the operation z[i] = z[i] + a*w[i]
     Third performs the operation w[i] = y[i] + b*w[i]

     First performs the operatio y[i] = y[i] + a*w[i]
     Second performs the operation z[i] = z[i] - a*x[i] 
     Third performs the operation w[i] = z[i] + b*w[i]
  */
  template <typename Float2, typename FloatN>
  struct tripleCGUpdate {
    Float2 a, b;
    tripleCGUpdate(const Float2 &a, const Float2 &b, const Float2 &c) : a(a), b(b) { ; }
/* DPCT_ORIG     __device__ void operator()(const FloatN &x, FloatN &y, FloatN
 * &z, FloatN &w) */
    SYCL_EXTERNAL void operator()(const FloatN &x, FloatN &y, FloatN &z,
                                  FloatN &w)
    //{ y -= a.x*x; z += a.x*w; w = y + b.x*w; }
/* DPCT_ORIG     { y += a.x*w; z -= a.x*x; w = z + b.x*w; }*/
    { y += static_cast<double>(a.x()) * w; z -= static_cast<double>(a.x()) * x; w = z + static_cast<double>(b.x()) * w; }
    static int streams() { return 7; } //! total number of input and output streams
    static int flops() { return 6; } //! flops per element
  };

  void tripleCGUpdateCuda(const double &a, const double &b, cudaColorSpinorField &x, 
		      cudaColorSpinorField &y, cudaColorSpinorField &z, cudaColorSpinorField &w) {
    if (x.Precision() != y.Precision()) {
      // call hacked mixed precision kernel
/* DPCT_ORIG       mixed::blasCuda<tripleCGUpdate,0,1,1,1>(make_double2(a,0.0),
 * make_double2(b,0.0), */
      mixed::blasCuda<tripleCGUpdate, 0, 1, 1, 1>(
          cl::sycl::double2(a, 0.0), cl::sycl::double2(b, 0.0),
          /* DPCT_ORIG 					      make_double2(0.0,0.0), x, y, z,
             w);*/
          cl::sycl::double2(0.0, 0.0), x, y, z, w);
    } else {
/* DPCT_ORIG       blasCuda<tripleCGUpdate,0,1,1,1>(make_double2(a, 0.0),
 * make_double2(b, 0.0), */
      blasCuda<tripleCGUpdate, 0, 1, 1, 1>(
          cl::sycl::double2(a, 0.0), cl::sycl::double2(b, 0.0),
          /* DPCT_ORIG 				       make_double2(0.0, 0.0), x, y, z,
             w);*/
          cl::sycl::double2(0.0, 0.0), x, y, z, w);
    }
  }

} // namespace quda
