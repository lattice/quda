#include <CL/sycl.hpp>
#include <dpct/dpct.hpp>
#include <blas_quda.h>
#include <tune_quda.h>
#include <float_vector.h>

#if (__COMPUTE_CAPABILITY__ >= 130)
#define QudaSumFloat double
#define QudaSumFloat2 double2
#define QudaSumFloat3 double3
#else
#define QudaSumFloat doublesingle
#define QudaSumFloat2 doublesingle2
#define QudaSumFloat3 doublesingle3
#include <double_single.h>
#endif

#define REDUCE_MAX_BLOCKS 65536

#define checkSpinor(a, b)						\
  {									\
    if (a.Precision() != b.Precision())					\
      errorQuda("precisions do not match: %d %d", a.Precision(), b.Precision()); \
    if (a.Length() != b.Length())					\
      errorQuda("lengths do not match: %d %d", a.Length(), b.Length());	\
    if (a.Stride() != b.Stride())					\
      errorQuda("strides do not match: %d %d", a.Stride(), b.Stride());	\
  }

#define checkLength(a, b)						\
  {									\
    if (a.Length() != b.Length())					\
      errorQuda("lengths do not match: %d %d", a.Length(), b.Length());	\
    if (a.Stride() != b.Stride())					\
      errorQuda("strides do not match: %d %d", a.Stride(), b.Stride());	\
  }

static struct dpct_type_e9e343 {
  const char *vol_str;
  const char *aux_str;
  char aux_tmp[quda::TuneKey::aux_n];
} blasStrings;

// These are used for reduction kernels
static QudaSumFloat *d_reduce=0;
static QudaSumFloat *h_reduce=0;
static QudaSumFloat *hd_reduce=0;
/* DPCT_ORIG static cudaEvent_t reduceEnd;*/
static cl::sycl::event reduceEnd;

namespace quda {

/* DPCT_ORIG   cudaStream_t* getBlasStream();*/
  queue_p *getBlasStream();

  void initReduce()
  {

    const int MaxReduce = 12;
    // reduction buffer size
    size_t bytes = MaxReduce*3*REDUCE_MAX_BLOCKS*sizeof(QudaSumFloat); // Factor of N for composite reductions


    if (!d_reduce) d_reduce = (QudaSumFloat *) device_malloc(bytes);

    // these arrays are actually oversized currently (only needs to be QudaSumFloat3)

    // if the device supports host-mapped memory then use a host-mapped array for the reduction
    if (!h_reduce) {
      // only use zero copy reductions when using 64-bit
#if (defined(_MSC_VER) && defined(_WIN64)) || defined(__LP64__)
      if(deviceProp.canMapHostMemory) {
	h_reduce = (QudaSumFloat *) mapped_malloc(bytes);
/* DPCT_ORIG 	cudaHostGetDevicePointer(&hd_reduce, h_reduce, 0); */
	*(&hd_reduce) = h_reduce; // set the matching device pointer
      } else
#endif
      {
	h_reduce = (QudaSumFloat *) pinned_malloc(bytes);
	hd_reduce = d_reduce;
      }
      memset(h_reduce, 0, bytes); // added to ensure that valgrind doesn't report h_reduce is unitialised
    }

/* DPCT_ORIG     cudaEventCreateWithFlags(&reduceEnd, cudaEventDisableTiming);*/
    /*
    DPCT1026:0: The call to cudaEventCreateWithFlags was removed, because
    Function call is redundant in DPC++.
    */

    checkCudaError();
  }

  void endReduce(void)
  {
    if (d_reduce) {
      device_free(d_reduce);
      d_reduce = 0;
    }
    if (h_reduce) {
      host_free(h_reduce);
      h_reduce = 0;
    }
    hd_reduce = 0;

/* DPCT_ORIG     cudaEventDestroy(reduceEnd);*/
    /*
    DPCT1026:1: The call to cudaEventDestroy was removed, because Function call
    is redundant in DPC++.
    */
  }

  namespace reduce {

#include <texture.h>
#include <reduce_core.h>
#include <reduce_mixed_core.h>

using queue_p = cl::sycl::queue *;

  } // namespace reduce

  /**
     Base class from which all reduction functors should derive.
  */
  template <typename ReduceType, typename Float2, typename FloatN>
  struct ReduceFunctor {

    //! pre-computation routine called before the "M-loop"
/* DPCT_ORIG     virtual __device__ void pre() { ; }*/
    SYCL_EXTERNAL virtual void pre() { ; }

    //! where the reduction is usually computed and any auxiliary operations
/* DPCT_ORIG     virtual __device__ void operator()(ReduceType &sum, FloatN &x,
 * FloatN &y,*/
    virtual void operator()(ReduceType &sum, FloatN &x, FloatN &y, FloatN &z,
                            FloatN &w, FloatN &v) = 0;

    //! post-computation routine called after the "M-loop"
/* DPCT_ORIG     virtual __device__ void post(ReduceType &sum) { ; }*/
    SYCL_EXTERNAL virtual void post(ReduceType &sum) { ; }

  };

  /**
     Return the L2 norm of x
  */
/* DPCT_ORIG   __device__ double norm2_(const double2 &a) { return a.x*a.x +
 * a.y*a.y; }*/
  double norm2_(const cl::sycl::double2 &a) { return static_cast<const double>(a.x()) * static_cast<const double>(a.x()) +
         static_cast<const double>(a.y()) * static_cast<const double>(a.y()); }
/* DPCT_ORIG   __device__ float norm2_(const float2 &a) { return a.x*a.x +
 * a.y*a.y; }*/
  float norm2_(const cl::sycl::float2 &a) { return static_cast<const float>(a.x()) * static_cast<const float>(a.x()) +
         static_cast<const float>(a.y()) * static_cast<const float>(a.y()); }
/* DPCT_ORIG   __device__ float norm2_(const float4 &a) { return a.x*a.x +
 * a.y*a.y + a.z*a.z + a.w*a.w; }*/
  float norm2_(const cl::sycl::float4 &a) { return static_cast<const float>(a.x()) * static_cast<const float>(a.x()) +
         static_cast<const float>(a.y()) * static_cast<const float>(a.y()) +
         static_cast<const float>(a.z()) * static_cast<const float>(a.z()) +
         static_cast<const float>(a.w()) * static_cast<const float>(a.w()); }

  template <typename ReduceType, typename Float2, typename FloatN>
#if (__COMPUTE_CAPABILITY__ >= 200)
  struct Norm2 : public ReduceFunctor<ReduceType, Float2, FloatN> {
#else
  struct Norm2 {
#endif
    Norm2(const Float2 &a, const Float2 &b) { ; }
/* DPCT_ORIG     __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z,FloatN  &w, FloatN &v) { sum += norm2_(x); }*/
    void operator()(ReduceType &sum, FloatN &x, FloatN &y, FloatN &z, FloatN &w,
                    FloatN &v) { sum += norm2_(x); }
    static int streams() { return 1; } //! total number of input and output streams
    static int flops() { return 2; } //! flops per element
  };

  double normCuda(const cudaColorSpinorField &x) try {
    cudaColorSpinorField &y = (cudaColorSpinorField&)x; // FIXME
    return reduce::reduceCuda<double, QudaSumFloat, QudaSumFloat, Norm2, 0, 0,
                              0, 0, 0, false>
        /* DPCT_ORIG       (make_double2(0.0, 0.0), make_double2(0.0, 0.0), y,
           y, y, y, y);*/
        (cl::sycl::double2(0.0, 0.0), cl::sycl::double2(0.0, 0.0), y, y, y, y,
         y);
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

  /**
     Return the real dot product of x and y
  */
/* DPCT_ORIG   __device__ double dot_(const double2 &a, const double2 &b) {
 * return a.x*b.x + a.y*b.y; }*/
  double dot_(const cl::sycl::double2 &a, const cl::sycl::double2 &b) { return static_cast<const double>(a.x()) * static_cast<const double>(b.x()) +
         static_cast<const double>(a.y()) * static_cast<const double>(b.y()); }
/* DPCT_ORIG   __device__ float dot_(const float2 &a, const float2 &b) { return
 * a.x*b.x + a.y*b.y; }*/
  float dot_(const cl::sycl::float2 &a, const cl::sycl::float2 &b) { return static_cast<const float>(a.x()) * static_cast<const float>(b.x()) +
         static_cast<const float>(a.y()) * static_cast<const float>(b.y()); }
/* DPCT_ORIG   __device__ float dot_(const float4 &a, const float4 &b) { return
 * a.x*b.x + a.y*b.y + a.z*b.z + a.w*b.w; }*/
  float dot_(const cl::sycl::float4 &a, const cl::sycl::float4 &b) { return static_cast<const float>(a.x()) * static_cast<const float>(b.x()) +
         static_cast<const float>(a.y()) * static_cast<const float>(b.y()) +
         static_cast<const float>(a.z()) * static_cast<const float>(b.z()) +
         static_cast<const float>(a.w()) * static_cast<const float>(b.w()); }

  template <typename ReduceType, typename Float2, typename FloatN>
#if (__COMPUTE_CAPABILITY__ >= 200)
  struct Dot : public ReduceFunctor<ReduceType, Float2, FloatN> {
#else
  struct Dot {
#endif
    Dot(const Float2 &a, const Float2 &b) { ; }
/* DPCT_ORIG     __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z, FloatN &w, FloatN &v) { sum += dot_(x,y); }*/
    void operator()(ReduceType &sum, FloatN &x, FloatN &y, FloatN &z, FloatN &w,
                    FloatN &v) { sum += dot_(x,y); }
    static int streams() { return 2; } //! total number of input and output streams
    static int flops() { return 2; } //! flops per element
  };

  double reDotProductCuda(cudaColorSpinorField &x,
                          cudaColorSpinorField &y) try {
    return reduce::reduceCuda<double, QudaSumFloat, QudaSumFloat, Dot, 0, 0, 0,
                              0, 0, false>
        /* DPCT_ORIG       (make_double2(0.0, 0.0), make_double2(0.0, 0.0), x,
           y, x, x, x);*/
        (cl::sycl::double2(0.0, 0.0), cl::sycl::double2(0.0, 0.0), x, y, x, x,
         x);
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

  void reDotProductCuda(double* result, std::vector<cudaColorSpinorField*>& x, std::vector<cudaColorSpinorField*>& y){
#ifndef SSTEP
    errorQuda("S-step code not built\n");
#else
    switch(x.size()){
      case 1:
        reduce::multiReduceCuda<1,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 2:
        reduce::multiReduceCuda<2,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 3:
        reduce::multiReduceCuda<3,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 4:
        reduce::multiReduceCuda<4,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 5:
        reduce::multiReduceCuda<5,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 6:
        reduce::multiReduceCuda<6,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 7:
        reduce::multiReduceCuda<7,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 8:
        reduce::multiReduceCuda<8,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 9:
        reduce::multiReduceCuda<9,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 10:
        reduce::multiReduceCuda<10,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 11:
        reduce::multiReduceCuda<11,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 12:
        reduce::multiReduceCuda<12,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 13:
        reduce::multiReduceCuda<13,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 14:
        reduce::multiReduceCuda<14,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 15:
        reduce::multiReduceCuda<15,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 16:
        reduce::multiReduceCuda<16,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 17:
        reduce::multiReduceCuda<17,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 18:
        reduce::multiReduceCuda<18,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 19:
        reduce::multiReduceCuda<19,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 20:
        reduce::multiReduceCuda<20,double,QudaSumFloat,QudaSumFloat,Dot,0,0,0,0,0,false>
        (result, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      default:
        errorQuda("Unsupported vector size");
        break;
    }
#endif // SSTEP
  }


    /*
      returns the real component of the dot product of a and b
      and the norm of a
    */
/* DPCT_ORIG   __device__ double2 dotNormA_(const double2 &a, const double2
 * &b)*/
  cl::sycl::double2 dotNormA_(const cl::sycl::double2 &a,
                              const cl::sycl::double2 &b)
/* DPCT_ORIG   { return make_double2(a.x*b.x + a.y*b.y, a.x*a.x + a.y*a.y); }*/
  { return cl::sycl::double2(
      static_cast<const double>(a.x()) * static_cast<const double>(b.x()) +
          static_cast<const double>(a.y()) * static_cast<const double>(b.y()),
      static_cast<const double>(a.x()) * static_cast<const double>(a.x()) +
          static_cast<const double>(a.y()) * static_cast<const double>(a.y())); }

/* DPCT_ORIG   __device__ double2 dotNormA_(const float2 &a, const float2 &b)*/
  cl::sycl::double2 dotNormA_(const cl::sycl::float2 &a,
                              const cl::sycl::float2 &b)
/* DPCT_ORIG   { return make_double2(a.x*b.x + a.y*b.y, a.x*a.x + a.y*a.y); }*/
  { return cl::sycl::double2(
      static_cast<const float>(a.x()) * static_cast<const float>(b.x()) +
          static_cast<const float>(a.y()) * static_cast<const float>(b.y()),
      static_cast<const float>(a.x()) * static_cast<const float>(a.x()) +
          static_cast<const float>(a.y()) * static_cast<const float>(a.y())); }


/* DPCT_ORIG   __device__ double2 dotNormA_(const float4 &a, const float4 & b)*/
  cl::sycl::double2 dotNormA_(const cl::sycl::float4 &a,
                              const cl::sycl::float4 &b)
/* DPCT_ORIG   { return make_double2(a.x*b.x + a.y*b.y + a.z*b.z + a.w*b.w,
 * a.x*a.x + a.y*a.y + a.z*a.z +     a.w*a.w); }*/
  { return cl::sycl::double2(
      static_cast<const float>(a.x()) * static_cast<const float>(b.x()) +
          static_cast<const float>(a.y()) * static_cast<const float>(b.y()) +
          static_cast<const float>(a.z()) * static_cast<const float>(b.z()) +
          static_cast<const float>(a.w()) * static_cast<const float>(b.w()),
      static_cast<const float>(a.x()) * static_cast<const float>(a.x()) +
          static_cast<const float>(a.y()) * static_cast<const float>(a.y()) +
          static_cast<const float>(a.z()) * static_cast<const float>(a.z()) +
          static_cast<const float>(a.w()) * static_cast<const float>(a.w())); }



  template <typename ReduceType, typename Float2, typename FloatN>
#if (__COMPUTE_CAPABILITY__ >= 200)
  struct DotNormA : public ReduceFunctor<ReduceType, Float2, FloatN> {
#else
  struct DotNormA {
#endif
    DotNormA(const Float2 &a, const Float2 &b){}
/* DPCT_ORIG     __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z,  FloatN &w, FloatN &v){sum += dotNormA_(x,y);}*/
    void operator()(ReduceType &sum, FloatN &x, FloatN &y, FloatN &z, FloatN &w,
                    FloatN &v) {sum += dotNormA_(x,y);}
    static int streams() { return 2; }
    static int flops() { return 4; }
  };

/* DPCT_ORIG   double2 reDotProductNormACuda(cudaColorSpinorField
 * &x,cudaColorSpinorField &y){*/
  cl::sycl::double2 reDotProductNormACuda(cudaColorSpinorField &x,
                                          cudaColorSpinorField &y) try {
    return reduce::reduceCuda<double2, QudaSumFloat2, QudaSumFloat, DotNormA, 0,
                              0, 0, 0, 0, false>
        /* DPCT_ORIG       (make_double2(0.0, 0.0), make_double2(0.0, 0.0), x,
           y, x, x, x);*/
        (cl::sycl::double2(0.0, 0.0), cl::sycl::double2(0.0, 0.0), x, y, x, x,
         x);
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

  /**
     First performs the operation y[i] = a*x[i]
     Return the norm of y
  */
  template <typename ReduceType, typename Float2, typename FloatN>
#if (__COMPUTE_CAPABILITY__ >= 200)
  struct axpyNorm2 : public ReduceFunctor<ReduceType, Float2, FloatN> {
#else
  struct axpyNorm2 {
#endif
    Float2 a;
    axpyNorm2(const Float2 &a, const Float2 &b) : a(a) { ; }
/* DPCT_ORIG     __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z, FloatN &w, FloatN &v) {*/
    void operator()(ReduceType &sum, FloatN &x, FloatN &y, FloatN &z, FloatN &w,
                    FloatN &v) {
/* DPCT_ORIG       y += a.x*x; sum += norm2_(y); }*/
      y += static_cast<double>(a.x()) * x; sum += norm2_(y); }
    static int streams() { return 3; } //! total number of input and output streams
    static int flops() { return 4; } //! flops per element
  };

  double axpyNormCuda(const double &a, cudaColorSpinorField &x,
                      cudaColorSpinorField &y) try {
    return reduce::reduceCuda<double, QudaSumFloat, QudaSumFloat, axpyNorm2, 0,
                              1, 0, 0, 0, false>
        /* DPCT_ORIG       (make_double2(a, 0.0), make_double2(0.0, 0.0), x, y,
           x, x, x);*/
        (cl::sycl::double2(a, 0.0), cl::sycl::double2(0.0, 0.0), x, y, x, x, x);
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

  /**
     First performs the operation y[i] = x[i] - y[i]
     Second returns the norm of y
  */
  template <typename ReduceType, typename Float2, typename FloatN>
#if (__COMPUTE_CAPABILITY__ >= 200)
  struct xmyNorm2 : public ReduceFunctor<ReduceType, Float2, FloatN> {
#else
  struct xmyNorm2 {
#endif
    xmyNorm2(const Float2 &a, const Float2 &b) { ; }
/* DPCT_ORIG     __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z, FloatN &w, FloatN &v) {*/
    void operator()(ReduceType &sum, FloatN &x, FloatN &y, FloatN &z, FloatN &w,
                    FloatN &v) {
      y = x - y; sum += norm2_(y); }
    static int streams() { return 3; } //! total number of input and output streams
    static int flops() { return 3; } //! flops per element
  };

  double xmyNormCuda(cudaColorSpinorField &x, cudaColorSpinorField &y) try {
    return reduce::reduceCuda<double, QudaSumFloat, QudaSumFloat, xmyNorm2, 0,
                              1, 0, 0, 0, false>
        /* DPCT_ORIG       (make_double2(0.0, 0.0), make_double2(0.0, 0.0), x,
           y, x, x, x);*/
        (cl::sycl::double2(0.0, 0.0), cl::sycl::double2(0.0, 0.0), x, y, x, x,
         x);
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

  /**
     Functor to perform the operation y += a * x  (complex-valued)
  */

/* DPCT_ORIG   __device__ void Caxpy_(const float2 &a, const float4 &x, float4
 * &y) {*/
  void Caxpy_(const cl::sycl::float2 &a, const cl::sycl::float4 &x,
              cl::sycl::float4 &y) {
/* DPCT_ORIG     y.x += a.x*x.x; y.x -= a.y*x.y;*/
    y.x() += static_cast<const float>(a.x()) * static_cast<const float>(x.x()); y.x() -= static_cast<const float>(a.y()) * static_cast<const float>(x.y());
/* DPCT_ORIG     y.y += a.y*x.x; y.y += a.x*x.y;*/
    y.y() += static_cast<const float>(a.y()) * static_cast<const float>(x.x()); y.y() += static_cast<const float>(a.x()) * static_cast<const float>(x.y());
/* DPCT_ORIG     y.z += a.x*x.z; y.z -= a.y*x.w;*/
    y.z() += static_cast<const float>(a.x()) * static_cast<const float>(x.z()); y.z() -= static_cast<const float>(a.y()) * static_cast<const float>(x.w());
/* DPCT_ORIG     y.w += a.y*x.z; y.w += a.x*x.w;*/
    y.w() += static_cast<const float>(a.y()) * static_cast<const float>(x.z()); y.w() += static_cast<const float>(a.x()) * static_cast<const float>(x.w());
  }

/* DPCT_ORIG   __device__ void Caxpy_(const float2 &a, const float2 &x, float2
 * &y) {*/
  void Caxpy_(const cl::sycl::float2 &a, const cl::sycl::float2 &x,
              cl::sycl::float2 &y) {
/* DPCT_ORIG     y.x += a.x*x.x; y.x -= a.y*x.y;*/
    y.x() += static_cast<const float>(a.x()) * static_cast<const float>(x.x()); y.x() -= static_cast<const float>(a.y()) * static_cast<const float>(x.y());
/* DPCT_ORIG     y.y += a.y*x.x; y.y += a.x*x.y;*/
    y.y() += static_cast<const float>(a.y()) * static_cast<const float>(x.x()); y.y() += static_cast<const float>(a.x()) * static_cast<const float>(x.y());
  }

/* DPCT_ORIG   __device__ void Caxpy_(const double2 &a, const double2 &x,
 * double2 &y) {*/
  void Caxpy_(const cl::sycl::double2 &a, const cl::sycl::double2 &x,
              cl::sycl::double2 &y) {
/* DPCT_ORIG     y.x += a.x*x.x; y.x -= a.y*x.y;*/
    y.x() +=
        static_cast<const double>(a.x()) * static_cast<const double>(x.x()); y.x() -=
        static_cast<const double>(a.y()) * static_cast<const double>(x.y());
/* DPCT_ORIG     y.y += a.y*x.x; y.y += a.x*x.y;*/
    y.y() +=
        static_cast<const double>(a.y()) * static_cast<const double>(x.x()); y.y() +=
        static_cast<const double>(a.x()) * static_cast<const double>(x.y());
  }

  /**
     First performs the operation y[i] = a*x[i] + y[i] (complex-valued)
     Second returns the norm of y
  */
  template <typename ReduceType, typename Float2, typename FloatN>
#if (__COMPUTE_CAPABILITY__ >= 200)
  struct caxpyNorm2 : public ReduceFunctor<ReduceType, Float2, FloatN> {
#else
  struct caxpyNorm2 {
#endif
    Float2 a;
    caxpyNorm2(const Float2 &a, const Float2 &b) : a(a) { ; }
/* DPCT_ORIG     __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z, FloatN &w, FloatN &v) {*/
    void operator()(ReduceType &sum, FloatN &x, FloatN &y, FloatN &z, FloatN &w,
                    FloatN &v) {
      Caxpy_(a, x, y); sum += norm2_(y); }
    static int streams() { return 3; } //! total number of input and output streams
    static int flops() { return 6; } //! flops per element
  };

  double caxpyNormCuda(const Complex &a, cudaColorSpinorField &x,
                       cudaColorSpinorField &y) try {
    return reduce::reduceCuda<double, QudaSumFloat, QudaSumFloat, caxpyNorm2, 0,
                              1, 0, 0, 0, false>
        /* DPCT_ORIG       (make_double2(REAL(a), IMAG(a)), make_double2(0.0,
           0.0), x, y, x, x, x);*/
        (cl::sycl::double2(REAL(a), IMAG(a)), cl::sycl::double2(0.0, 0.0), x, y,
         x, x, x);
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

  /**
     double caxpyXmayNormCuda(float a, float *x, float *y, n){}

     First performs the operation y[i] += a*x[i]
     Second performs the operator x[i] -= a*z[i]
     Third returns the norm of x
  */
  template <typename ReduceType, typename Float2, typename FloatN>
#if (__COMPUTE_CAPABILITY__ >= 200)
  struct caxpyxmaznormx : public ReduceFunctor<ReduceType, Float2, FloatN> {
#else
  struct caxpyxmaznormx {
#endif
    Float2 a;
    caxpyxmaznormx(const Float2 &a, const Float2 &b) : a(a) { ; }
/* DPCT_ORIG     __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z, FloatN &w, FloatN &v) { Caxpy_(a, x, y); Caxpy_(-a, z, x); sum
 * += norm2_(x); }*/
    void operator()(ReduceType &sum, FloatN &x, FloatN &y, FloatN &z, FloatN &w,
                    FloatN &v) { Caxpy_(a, x, y); Caxpy_(-a, z, x); sum += norm2_(x); }
    static int streams() { return 5; } //! total number of input and output streams
    static int flops() { return 10; } //! flops per element
  };

  double caxpyXmazNormXCuda(const Complex &a, cudaColorSpinorField &x,
                            cudaColorSpinorField &y,
                            cudaColorSpinorField &z) try {
    return reduce::reduceCuda<double, QudaSumFloat, QudaSumFloat,
                              caxpyxmaznormx, 1, 1, 0, 0, 0, false>
        /* DPCT_ORIG       (make_double2(REAL(a), IMAG(a)), make_double2(0.0,
           0.0), x, y, z, x, x);*/
        (cl::sycl::double2(REAL(a), IMAG(a)), cl::sycl::double2(0.0, 0.0), x, y,
         z, x, x);
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

  /**
     double cabxpyAxNormCuda(float a, complex b, float *x, float *y, n){}

     First performs the operation y[i] += a*b*x[i]
     Second performs x[i] *= a
     Third returns the norm of x
  */
    template <typename ReduceType, typename Float2, typename FloatN>
#if (__COMPUTE_CAPABILITY__ >= 200)
    struct cabxpyaxnorm : public ReduceFunctor<ReduceType, Float2, FloatN> {
#else
    struct cabxpyaxnorm {
#endif
    Float2 a;
    Float2 b;
    cabxpyaxnorm(const Float2 &a, const Float2 &b) : a(a), b(b) { ; }
/* DPCT_ORIG       __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z, FloatN &w, FloatN &v) { x *= a.x; Caxpy_(b, x, y); sum +=
 * norm2_(y); }*/
      void operator()(ReduceType &sum, FloatN &x, FloatN &y, FloatN &z,
                      FloatN &w, FloatN &v) { x *= static_cast<double>(a.x()); Caxpy_(b, x, y); sum += norm2_(y); }
    static int streams() { return 4; } //! total number of input and output streams
    static int flops() { return 10; } //! flops per element
  };

  double cabxpyAxNormCuda(const double &a, const Complex &b,
                          cudaColorSpinorField &x,
                          cudaColorSpinorField &y) try {
    return reduce::reduceCuda<double, QudaSumFloat, QudaSumFloat, cabxpyaxnorm,
                              1, 1, 0, 0, 0, false>
        /* DPCT_ORIG       (make_double2(a, 0.0), make_double2(REAL(b),
           IMAG(b)), x, y, x, x, x);*/
        (cl::sycl::double2(a, 0.0), cl::sycl::double2(REAL(b), IMAG(b)), x, y,
         x, x, x);
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

  /**
     Returns complex-valued dot product of x and y
  */
/* DPCT_ORIG   __device__ double2 cdot_(const double2 &a, const double2 &b)*/
  cl::sycl::double2 cdot_(const cl::sycl::double2 &a,
                          const cl::sycl::double2 &b)
/* DPCT_ORIG   { return make_double2(a.x*b.x + a.y*b.y, a.x*b.y - a.y*b.x); }*/
  { return cl::sycl::double2(
      static_cast<const double>(a.x()) * static_cast<const double>(b.x()) +
          static_cast<const double>(a.y()) * static_cast<const double>(b.y()),
      static_cast<const double>(a.x()) * static_cast<const double>(b.y()) -
          static_cast<const double>(a.y()) * static_cast<const double>(b.x())); }
/* DPCT_ORIG   __device__ double2 cdot_(const float2 &a, const float2 &b)*/
  cl::sycl::double2 cdot_(const cl::sycl::float2 &a, const cl::sycl::float2 &b)
/* DPCT_ORIG   { return make_double2(a.x*b.x + a.y*b.y, a.x*b.y - a.y*b.x); }*/
  { return cl::sycl::double2(
      static_cast<const float>(a.x()) * static_cast<const float>(b.x()) +
          static_cast<const float>(a.y()) * static_cast<const float>(b.y()),
      static_cast<const float>(a.x()) * static_cast<const float>(b.y()) -
          static_cast<const float>(a.y()) * static_cast<const float>(b.x())); }
/* DPCT_ORIG   __device__ double2 cdot_(const float4 &a, const float4 &b)*/
  cl::sycl::double2 cdot_(const cl::sycl::float4 &a, const cl::sycl::float4 &b)
/* DPCT_ORIG   { return make_double2(a.x*b.x + a.y*b.y + a.z*b.z + a.w*b.w,
 * a.x*b.y - a.y*b.x + a.z*b.w - a.w*b.z); }*/
  { return cl::sycl::double2(
      static_cast<const float>(a.x()) * static_cast<const float>(b.x()) +
          static_cast<const float>(a.y()) * static_cast<const float>(b.y()) +
          static_cast<const float>(a.z()) * static_cast<const float>(b.z()) +
          static_cast<const float>(a.w()) * static_cast<const float>(b.w()),
      static_cast<const float>(a.x()) * static_cast<const float>(b.y()) -
          static_cast<const float>(a.y()) * static_cast<const float>(b.x()) +
          static_cast<const float>(a.z()) * static_cast<const float>(b.w()) -
          static_cast<const float>(a.w()) * static_cast<const float>(b.z())); }

  template <typename ReduceType, typename Float2, typename FloatN>
#if (__COMPUTE_CAPABILITY__ >= 200)
  struct Cdot : public ReduceFunctor<ReduceType, Float2, FloatN> {
#else
  struct Cdot {
#endif
    Cdot(const Float2 &a, const Float2 &b) { ; }
/* DPCT_ORIG     __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z, FloatN &w, FloatN &v) { sum += cdot_(x,y); }*/
    void operator()(ReduceType &sum, FloatN &x, FloatN &y, FloatN &z, FloatN &w,
                    FloatN &v) { sum += cdot_(x,y); }
    static int streams() { return 2; } //! total number of input and output streams
    static int flops() { return 4; } //! flops per element
  };

  Complex cDotProductCuda(cudaColorSpinorField &x,
                          cudaColorSpinorField &y) try {
/* DPCT_ORIG     double2 cdot =
 * reduce::reduceCuda<double2,QudaSumFloat2,QudaSumFloat,Cdot,0,0,0,0,0,false>*/
    cl::sycl::double2 cdot =
        reduce::reduceCuda<double2, QudaSumFloat2, QudaSumFloat, Cdot, 0, 0, 0,
                           0, 0, false>
        /* DPCT_ORIG       (make_double2(0.0, 0.0), make_double2(0.0, 0.0), x,
           y, x, x, x);*/
        (cl::sycl::double2(0.0, 0.0), cl::sycl::double2(0.0, 0.0), x, y, x, x,
         x);
/* DPCT_ORIG     return Complex(cdot.x, cdot.y);*/
    return Complex(static_cast<double>(cdot.x()),
                   static_cast<double>(cdot.y()));
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

  void cDotProductCuda(Complex* result, std::vector<cudaColorSpinorField*>& x, std::vector<cudaColorSpinorField*>& y){
#ifndef SSTEP
    errorQuda("S-step code not built\n");
#else
    double2* cdot = new double2[x.size()];

    switch(x.size()){
      case 1:
        reduce::multiReduceCuda<1,double2,QudaSumFloat2,QudaSumFloat,Cdot,0,0,0,0,0,false>
        (cdot, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 6:
        reduce::multiReduceCuda<6,double2,QudaSumFloat2,QudaSumFloat,Cdot,0,0,0,0,0,false>
        (cdot, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 10:
        reduce::multiReduceCuda<10,double2,QudaSumFloat2,QudaSumFloat,Cdot,0,0,0,0,0,false>
        (cdot, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 14:
        reduce::multiReduceCuda<14,double2,QudaSumFloat2,QudaSumFloat,Cdot,0,0,0,0,0,false>
        (cdot, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 18:
        reduce::multiReduceCuda<18,double2,QudaSumFloat2,QudaSumFloat,Cdot,0,0,0,0,0,false>
        (cdot, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      case 22:
        reduce::multiReduceCuda<22,double2,QudaSumFloat2,QudaSumFloat,Cdot,0,0,0,0,0,false>
        (cdot, make_double2(0.0, 0.0), make_double2(0.0, 0.0), x, y, x, x, x);
        break;
      default:
        errorQuda("Unsupported vector size\n");
        break;
    }

    for(int i=0; i<x.size(); ++i) result[i] = Complex(cdot[i].x,cdot[i].y);
    delete[] cdot;
#endif
  }

  /**
     double2 xpaycDotzyCuda(float2 *x, float a, float2 *y, float2 *z, int n) {}

     First performs the operation y = x + a*y
     Second returns cdot product (z,y)
  */
  template <typename ReduceType, typename Float2, typename FloatN>
#if (__COMPUTE_CAPABILITY__ >= 200)
  struct xpaycdotzy : public ReduceFunctor<ReduceType, Float2, FloatN> {
#else
  struct xpaycdotzy {
#endif
    Float2 a;
    xpaycdotzy(const Float2 &a, const Float2 &b) : a(a) { ; }
/* DPCT_ORIG     __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z, FloatN &w, FloatN &v) { y = x + a.x*y; sum += cdot_(z,y); }*/
    void operator()(ReduceType &sum, FloatN &x, FloatN &y, FloatN &z, FloatN &w,
                    FloatN &v) { y = x + static_cast<double>(a.x()) * y; sum += cdot_(z,y); }
    static int streams() { return 4; } //! total number of input and output streams
    static int flops() { return 6; } //! flops per element
  };

  Complex xpaycDotzyCuda(cudaColorSpinorField &x, const double &a,
                         cudaColorSpinorField &y, cudaColorSpinorField &z) try {
/* DPCT_ORIG     double2 cdot =
 * reduce::reduceCuda<double2,QudaSumFloat2,QudaSumFloat,xpaycdotzy,0,1,0,0,0,false>*/
    cl::sycl::double2 cdot =
        reduce::reduceCuda<double2, QudaSumFloat2, QudaSumFloat, xpaycdotzy, 0,
                           1, 0, 0, 0, false>
        /* DPCT_ORIG       (make_double2(a, 0.0), make_double2(0.0, 0.0), x, y,
           z, x, x);*/
        (cl::sycl::double2(a, 0.0), cl::sycl::double2(0.0, 0.0), x, y, z, x, x);
/* DPCT_ORIG     return Complex(cdot.x, cdot.y);*/
    return Complex(static_cast<double>(cdot.x()),
                   static_cast<double>(cdot.y()));
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

  /**
     double caxpyDotzyCuda(float a, float *x, float *y, float *z, n){}

     First performs the operation y[i] = a*x[i] + y[i]
     Second returns the dot product (z,y)
  */
  template <typename ReduceType, typename Float2, typename FloatN>
#if (__COMPUTE_CAPABILITY__ >= 200)
  struct caxpydotzy : public ReduceFunctor<ReduceType, Float2, FloatN> {
#else
  struct caxpydotzy {
#endif
    Float2 a;
    caxpydotzy(const Float2 &a, const Float2 &b) : a(a) { ; }
/* DPCT_ORIG     __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z, FloatN &w, FloatN &v) { Caxpy_(a, x, y); sum += cdot_(z,y);
 * }*/
    void operator()(ReduceType &sum, FloatN &x, FloatN &y, FloatN &z, FloatN &w,
                    FloatN &v) { Caxpy_(a, x, y); sum += cdot_(z,y); }
    static int streams() { return 4; } //! total number of input and output streams
    static int flops() { return 8; } //! flops per element
  };

  Complex caxpyDotzyCuda(const Complex &a, cudaColorSpinorField &x,
                         cudaColorSpinorField &y, cudaColorSpinorField &z) try {
/* DPCT_ORIG     double2 cdot =
 * reduce::reduceCuda<double2,QudaSumFloat2,QudaSumFloat,caxpydotzy,0,1,0,0,0,false>*/
    cl::sycl::double2 cdot =
        reduce::reduceCuda<double2, QudaSumFloat2, QudaSumFloat, caxpydotzy, 0,
                           1, 0, 0, 0, false>
        /* DPCT_ORIG       (make_double2(REAL(a), IMAG(a)), make_double2(0.0,
           0.0), x, y, z, x, x);*/
        (cl::sycl::double2(REAL(a), IMAG(a)), cl::sycl::double2(0.0, 0.0), x, y,
         z, x, x);
/* DPCT_ORIG     return Complex(cdot.x, cdot.y);*/
    return Complex(static_cast<double>(cdot.x()),
                   static_cast<double>(cdot.y()));
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

  /**
     First returns the dot product (x,y)
     Returns the norm of x
  */
/* DPCT_ORIG   __device__ double3 cdotNormA_(const double2 &a, const double2
 * &b)*/
  cl::sycl::double3 cdotNormA_(const cl::sycl::double2 &a,
                               const cl::sycl::double2 &b)
/* DPCT_ORIG   { return make_double3(a.x*b.x + a.y*b.y, a.x*b.y - a.y*b.x,
 * a.x*a.x + a.y*a.y); }*/
  { return cl::sycl::double3(
      static_cast<const double>(a.x()) * static_cast<const double>(b.x()) +
          static_cast<const double>(a.y()) * static_cast<const double>(b.y()),
      static_cast<const double>(a.x()) * static_cast<const double>(b.y()) -
          static_cast<const double>(a.y()) * static_cast<const double>(b.x()),
      static_cast<const double>(a.x()) * static_cast<const double>(a.x()) +
          static_cast<const double>(a.y()) * static_cast<const double>(a.y())); }
/* DPCT_ORIG   __device__ double3 cdotNormA_(const float2 &a, const float2 &b)*/
  cl::sycl::double3 cdotNormA_(const cl::sycl::float2 &a,
                               const cl::sycl::float2 &b)
/* DPCT_ORIG   { return make_double3(a.x*b.x + a.y*b.y, a.x*b.y - a.y*b.x,
 * a.x*a.x + a.y*a.y); }*/
  { return cl::sycl::double3(
      static_cast<const float>(a.x()) * static_cast<const float>(b.x()) +
          static_cast<const float>(a.y()) * static_cast<const float>(b.y()),
      static_cast<const float>(a.x()) * static_cast<const float>(b.y()) -
          static_cast<const float>(a.y()) * static_cast<const float>(b.x()),
      static_cast<const float>(a.x()) * static_cast<const float>(a.x()) +
          static_cast<const float>(a.y()) * static_cast<const float>(a.y())); }
/* DPCT_ORIG   __device__ double3 cdotNormA_(const float4 &a, const float4 &b)*/
  cl::sycl::double3 cdotNormA_(const cl::sycl::float4 &a,
                               const cl::sycl::float4 &b)
/* DPCT_ORIG   { return make_double3(a.x*b.x + a.y*b.y + a.z*b.z + a.w*b.w,*/
  { return cl::sycl::double3(
      static_cast<const float>(a.x()) * static_cast<const float>(b.x()) +
          static_cast<const float>(a.y()) * static_cast<const float>(b.y()) +
          static_cast<const float>(a.z()) * static_cast<const float>(b.z()) +
          static_cast<const float>(a.w()) * static_cast<const float>(b.w()),
      /* DPCT_ORIG 			a.x*b.y - a.y*b.x + a.z*b.w - a.w*b.z,*/
      static_cast<const float>(a.x()) * static_cast<const float>(b.y()) -
          static_cast<const float>(a.y()) * static_cast<const float>(b.x()) +
          static_cast<const float>(a.z()) * static_cast<const float>(b.w()) -
          static_cast<const float>(a.w()) * static_cast<const float>(b.z()),
      /* DPCT_ORIG 			a.x*a.x + a.y*a.y + a.z*a.z +
         a.w*a.w); }*/
      static_cast<const float>(a.x()) * static_cast<const float>(a.x()) +
          static_cast<const float>(a.y()) * static_cast<const float>(a.y()) +
          static_cast<const float>(a.z()) * static_cast<const float>(a.z()) +
          static_cast<const float>(a.w()) * static_cast<const float>(a.w())); }

  template <typename ReduceType, typename Float2, typename FloatN>
#if (__COMPUTE_CAPABILITY__ >= 200)
  struct CdotNormA : public ReduceFunctor<ReduceType, Float2, FloatN> {
#else
  struct CdotNormA {
#endif
    CdotNormA(const Float2 &a, const Float2 &b) { ; }
/* DPCT_ORIG     __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z, FloatN &w, FloatN &v) { sum += cdotNormA_(x,y); }*/
    void operator()(ReduceType &sum, FloatN &x, FloatN &y, FloatN &z, FloatN &w,
                    FloatN &v) { sum += cdotNormA_(x,y); }
    static int streams() { return 2; } //! total number of input and output streams
    static int flops() { return 6; } //! flops per element
  };

/* DPCT_ORIG   double3 cDotProductNormACuda(cudaColorSpinorField &x,
 * cudaColorSpinorField &y) {*/
  cl::sycl::double3 cDotProductNormACuda(cudaColorSpinorField &x,
                                         cudaColorSpinorField &y) try {
    return reduce::reduceCuda<double3, QudaSumFloat3, QudaSumFloat, CdotNormA,
                              0, 0, 0, 0, 0, false>
        /* DPCT_ORIG       (make_double2(0.0, 0.0), make_double2(0.0, 0.0), x,
           y, x, x, x);*/
        (cl::sycl::double2(0.0, 0.0), cl::sycl::double2(0.0, 0.0), x, y, x, x,
         x);
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

  /**
     First returns the dot product (x,y)
     Returns the norm of y
  */
/* DPCT_ORIG   __device__ double3 cdotNormB_(const double2 &a, const double2
 * &b)*/
  cl::sycl::double3 cdotNormB_(const cl::sycl::double2 &a,
                               const cl::sycl::double2 &b)
/* DPCT_ORIG   { return make_double3(a.x*b.x + a.y*b.y, a.x*b.y - a.y*b.x,
 * b.x*b.x + b.y*b.y); }*/
  { return cl::sycl::double3(
      static_cast<const double>(a.x()) * static_cast<const double>(b.x()) +
          static_cast<const double>(a.y()) * static_cast<const double>(b.y()),
      static_cast<const double>(a.x()) * static_cast<const double>(b.y()) -
          static_cast<const double>(a.y()) * static_cast<const double>(b.x()),
      static_cast<const double>(b.x()) * static_cast<const double>(b.x()) +
          static_cast<const double>(b.y()) * static_cast<const double>(b.y())); }
/* DPCT_ORIG   __device__ double3 cdotNormB_(const float2 &a, const float2 &b)*/
  cl::sycl::double3 cdotNormB_(const cl::sycl::float2 &a,
                               const cl::sycl::float2 &b)
/* DPCT_ORIG   { return make_double3(a.x*b.x + a.y*b.y, a.x*b.y - a.y*b.x,
 * b.x*b.x + b.y*b.y); }*/
  { return cl::sycl::double3(
      static_cast<const float>(a.x()) * static_cast<const float>(b.x()) +
          static_cast<const float>(a.y()) * static_cast<const float>(b.y()),
      static_cast<const float>(a.x()) * static_cast<const float>(b.y()) -
          static_cast<const float>(a.y()) * static_cast<const float>(b.x()),
      static_cast<const float>(b.x()) * static_cast<const float>(b.x()) +
          static_cast<const float>(b.y()) * static_cast<const float>(b.y())); }
/* DPCT_ORIG   __device__ double3 cdotNormB_(const float4 &a, const float4 &b)*/
  cl::sycl::double3 cdotNormB_(const cl::sycl::float4 &a,
                               const cl::sycl::float4 &b)
/* DPCT_ORIG   { return make_double3(a.x*b.x + a.y*b.y + a.z*b.z + a.w*b.w,
 * a.x*b.y - a.y*b.x + a.z*b.w - a.w*b.z,*/
  { return cl::sycl::double3(
      static_cast<const float>(a.x()) * static_cast<const float>(b.x()) +
          static_cast<const float>(a.y()) * static_cast<const float>(b.y()) +
          static_cast<const float>(a.z()) * static_cast<const float>(b.z()) +
          static_cast<const float>(a.w()) * static_cast<const float>(b.w()),
      static_cast<const float>(a.x()) * static_cast<const float>(b.y()) -
          static_cast<const float>(a.y()) * static_cast<const float>(b.x()) +
          static_cast<const float>(a.z()) * static_cast<const float>(b.w()) -
          static_cast<const float>(a.w()) * static_cast<const float>(b.z()),
      /* DPCT_ORIG 			b.x*b.x + b.y*b.y + b.z*b.z +
         b.w*b.w); }*/
      static_cast<const float>(b.x()) * static_cast<const float>(b.x()) +
          static_cast<const float>(b.y()) * static_cast<const float>(b.y()) +
          static_cast<const float>(b.z()) * static_cast<const float>(b.z()) +
          static_cast<const float>(b.w()) * static_cast<const float>(b.w())); }

  template <typename ReduceType, typename Float2, typename FloatN>
#if (__COMPUTE_CAPABILITY__ >= 200)
  struct CdotNormB : public ReduceFunctor<ReduceType, Float2, FloatN> {
#else
  struct CdotNormB {
#endif
    CdotNormB(const Float2 &a, const Float2 &b) { ; }
/* DPCT_ORIG     __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z, FloatN &w, FloatN &v) { sum += cdotNormB_(x,y); }*/
    void operator()(ReduceType &sum, FloatN &x, FloatN &y, FloatN &z, FloatN &w,
                    FloatN &v) { sum += cdotNormB_(x,y); }
    static int streams() { return 2; } //! total number of input and output streams
    static int flops() { return 6; } //! flops per element
  };

/* DPCT_ORIG   double3 cDotProductNormBCuda(cudaColorSpinorField &x,
 * cudaColorSpinorField &y) {*/
  cl::sycl::double3 cDotProductNormBCuda(cudaColorSpinorField &x,
                                         cudaColorSpinorField &y) try {
    return reduce::reduceCuda<double3, QudaSumFloat3, QudaSumFloat, CdotNormB,
                              0, 0, 0, 0, 0, false>
        /* DPCT_ORIG       (make_double2(0.0, 0.0), make_double2(0.0, 0.0), x,
           y, x, x, x);*/
        (cl::sycl::double2(0.0, 0.0), cl::sycl::double2(0.0, 0.0), x, y, x, x,
         x);
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

  /**
     This convoluted kernel does the following:
     z += a*x + b*y, y -= b*w, norm = (y,y), dot = (u, y)
  */
  template <typename ReduceType, typename Float2, typename FloatN>
#if (__COMPUTE_CAPABILITY__ >= 200)
  struct caxpbypzYmbwcDotProductUYNormY : public ReduceFunctor<ReduceType, Float2, FloatN> {
#else
  struct caxpbypzYmbwcDotProductUYNormY {
#endif
    Float2 a;
    Float2 b;
    caxpbypzYmbwcDotProductUYNormY(const Float2 &a, const Float2 &b) : a(a), b(b) { ; }
/* DPCT_ORIG     __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z, FloatN &w, FloatN &v) { Caxpy_(a, x, z); Caxpy_(b, y, z);
 * Caxpy_(-b, w, y); sum += cdotNormB_(v,y); }*/
    SYCL_EXTERNAL void operator()(ReduceType &sum, FloatN &x, FloatN &y,
                                  FloatN &z, FloatN &w, FloatN &v) { Caxpy_(a, x, z); Caxpy_(b, y, z); Caxpy_(-b, w, y); sum += cdotNormB_(v,y); }
    static int streams() { return 7; } //! total number of input and output streams
    static int flops() { return 18; } //! flops per element
  };

/* DPCT_ORIG   double3 caxpbypzYmbwcDotProductUYNormYCuda(const Complex &a,
 * cudaColorSpinorField &x,*/
  cl::sycl::double3 caxpbypzYmbwcDotProductUYNormYCuda(
      const Complex &a, cudaColorSpinorField &x, const Complex &b,
      cudaColorSpinorField &y, cudaColorSpinorField &z, cudaColorSpinorField &w,
      cudaColorSpinorField &u) try {
    if (x.Precision() != z.Precision()) {
      return reduce::mixed::reduceCuda<double3, QudaSumFloat3, QudaSumFloat,
                                       caxpbypzYmbwcDotProductUYNormY, 0, 1, 1,
                                       0, 0, false>
          /* DPCT_ORIG       (make_double2(REAL(a), IMAG(a)),
             make_double2(REAL(b), IMAG(b)), x, y, z, w, u);*/
          (cl::sycl::double2(REAL(a), IMAG(a)),
           cl::sycl::double2(REAL(b), IMAG(b)), x, y, z, w, u);
    } else {
      return reduce::reduceCuda<double3, QudaSumFloat3, QudaSumFloat,
                                caxpbypzYmbwcDotProductUYNormY, 0, 1, 1, 0, 0,
                                false>
          /* DPCT_ORIG       (make_double2(REAL(a), IMAG(a)),
             make_double2(REAL(b), IMAG(b)), x, y, z, w, u);*/
          (cl::sycl::double2(REAL(a), IMAG(a)),
           cl::sycl::double2(REAL(b), IMAG(b)), x, y, z, w, u);
    }
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

  /**
     Specialized kernel for the modified CG norm computation for
     computing beta.  Computes y = y + a*x and returns norm(y) and
     dot(y, delta(y)) where delta(y) is the difference between the
     input and out y vector.
  */
  template <typename ReduceType, typename Float2, typename FloatN>
#if (__COMPUTE_CAPABILITY__ >= 200)
  struct axpyCGNorm2 : public ReduceFunctor<ReduceType, Float2, FloatN> {
#else
  struct axpyCGNorm2 {
#endif
    Float2 a;
    axpyCGNorm2(const Float2 &a, const Float2 &b) : a(a) { ; }
/* DPCT_ORIG     __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z, FloatN &w, FloatN &v) {*/
    void operator()(ReduceType &sum, FloatN &x, FloatN &y, FloatN &z, FloatN &w,
                    FloatN &v) {
/* DPCT_ORIG       FloatN y_new = y + a.x*x;*/
      FloatN y_new = y + static_cast<double>(a.x()) * x;
/* DPCT_ORIG       sum.x += norm2_(y_new);*/
      sum.x() += norm2_(y_new);
/* DPCT_ORIG       sum.y += dot_(y_new, y_new-y);*/
      sum.y() += dot_(y_new, y_new - y);
      y = y_new;
    }
    static int streams() { return 3; } //! total number of input and output streams
    static int flops() { return 6; } //! flops per real element
  };

  Complex axpyCGNormCuda(const double &a, cudaColorSpinorField &x,
                         cudaColorSpinorField &y) try {
/* DPCT_ORIG     double2 cg_norm =
 * reduce::reduceCuda<double2,QudaSumFloat2,QudaSumFloat,axpyCGNorm2,0,1,0,0,0,false>*/
    cl::sycl::double2 cg_norm =
        reduce::reduceCuda<double2, QudaSumFloat2, QudaSumFloat, axpyCGNorm2, 0,
                           1, 0, 0, 0, false>
        /* DPCT_ORIG       (make_double2(a, 0.0), make_double2(0.0, 0.0), x, y,
           x, x, x);*/
        (cl::sycl::double2(a, 0.0), cl::sycl::double2(0.0, 0.0), x, y, x, x, x);
/* DPCT_ORIG     return Complex(cg_norm.x, cg_norm.y);*/
    return Complex(static_cast<double>(cg_norm.x()),
                   static_cast<double>(cg_norm.y()));
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

#if (__COMPUTE_CAPABILITY__ >= 200)

  /**
     This kernel returns (x, x) and (r,r) and also returns the so-called
     heavy quark norm as used by MILC: 1 / N * \sum_i (r, r)_i / (x, x)_i, where
     i is site index and N is the number of sites.

     When this kernel is launched, we must enforce that the parameter M
     in the launcher corresponds to the number of FloatN fields used to
     represent the spinor, e.g., M=6 for Wilson and M=3 for staggered.
     This is only the case for half-precision kernels by default.  To
     enable this, the siteUnroll template parameter must be set true
     when reduceCuda is instantiated.
  */
  template <typename ReduceType, typename Float2, typename FloatN>
  struct HeavyQuarkResidualNorm : public ReduceFunctor<ReduceType, Float2, FloatN> {
    Float2 a;
    Float2 b;
    ReduceType aux;
    HeavyQuarkResidualNorm(const Float2 &a, const Float2 &b) : a(a), b(b) { ; }

/* DPCT_ORIG     __device__ void pre() { aux.x = 0; aux.y = 0; }*/
    void pre() { aux.x() = 0; aux.y() = 0; }

/* DPCT_ORIG     __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z, FloatN &w, FloatN &v) { aux.x += norm2_(x); aux.y +=
 * norm2_(y); }*/
    void operator()(ReduceType &sum, FloatN &x, FloatN &y, FloatN &z, FloatN &w,
                    FloatN &v) { aux.x() += norm2_(x); aux.y() += norm2_(y); }

    //! sum the solution and residual norms, and compute the heavy-quark norm
/* DPCT_ORIG     __device__ void post(ReduceType &sum)*/
    void post(ReduceType &sum)
    {
/* DPCT_ORIG       sum.x += aux.x; sum.y += aux.y; sum.z += (aux.x > 0.0) ?
 * (aux.y / aux.x) : 1.0;*/
      sum.x() += static_cast<double>(aux.x()); sum.y() += static_cast<double>(aux.y()); sum.z() +=
          (static_cast<double>(aux.x()) > 0.0)
              ? (static_cast<double>(aux.y()) / static_cast<double>(aux.x()))
              : 1.0;
    }

    static int streams() { return 2; } //! total number of input and output streams
    static int flops() { return 4; } //! undercounts since it excludes the per-site division
  };

/* DPCT_ORIG   double3 HeavyQuarkResidualNormCuda(cudaColorSpinorField &x,
 * cudaColorSpinorField &r) {*/
  cl::sycl::double3 HeavyQuarkResidualNormCuda(cudaColorSpinorField &x,
                                               cudaColorSpinorField &r) try {
/* DPCT_ORIG     double3 rtn =
 * reduce::reduceCuda<double3,QudaSumFloat3,QudaSumFloat,HeavyQuarkResidualNorm,0,0,0,0,0,true>*/
    cl::sycl::double3 rtn =
        reduce::reduceCuda<double3, QudaSumFloat3, QudaSumFloat,
                           HeavyQuarkResidualNorm, 0, 0, 0, 0, 0, true>
        /* DPCT_ORIG       (make_double2(0.0, 0.0), make_double2(0.0, 0.0), x,
           r, r, r, r);*/
        (cl::sycl::double2(0.0, 0.0), cl::sycl::double2(0.0, 0.0), x, r, r, r,
         r);
#ifdef MULTI_GPU
    rtn.z /= (x.Volume()*comm_size());
#else
/* DPCT_ORIG     rtn.z /= x.Volume();*/
    rtn.z() /= x.Volume();
#endif
    return rtn;
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

  /**
     Variant of the HeavyQuarkResidualNorm kernel: this takes three
     arguments, the first two are summed together to form the
     solution, with the third being the residual vector.  This removes
     the need an additional xpy call in the solvers, impriving
     performance.
  */
  template <typename ReduceType, typename Float2, typename FloatN>
  struct xpyHeavyQuarkResidualNorm : public ReduceFunctor<ReduceType, Float2, FloatN> {
    Float2 a;
    Float2 b;
    ReduceType aux;
    xpyHeavyQuarkResidualNorm(const Float2 &a, const Float2 &b) : a(a), b(b) { ; }

/* DPCT_ORIG     __device__ void pre() { aux.x = 0; aux.y = 0; }*/
    void pre() { aux.x() = 0; aux.y() = 0; }

/* DPCT_ORIG     __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z, FloatN &w, FloatN &v)*/
    void operator()(ReduceType &sum, FloatN &x, FloatN &y, FloatN &z, FloatN &w,
                    FloatN &v)
/* DPCT_ORIG     { aux.x += norm2_(x + y); aux.y += norm2_(z); }*/
    { aux.x() += norm2_(x + y); aux.y() += norm2_(z); }

    //! sum the solution and residual norms, and compute the heavy-quark norm
/* DPCT_ORIG     __device__ void post(ReduceType &sum)*/
    void post(ReduceType &sum)
    {
/* DPCT_ORIG       sum.x += aux.x; sum.y += aux.y; sum.z += (aux.x > 0.0) ?
 * (aux.y / aux.x) : 1.0;*/
      sum.x() += static_cast<double>(aux.x()); sum.y() += static_cast<double>(aux.y()); sum.z() +=
          (static_cast<double>(aux.x()) > 0.0)
              ? (static_cast<double>(aux.y()) / static_cast<double>(aux.x()))
              : 1.0;
    }

    static int streams() { return 3; } //! total number of input and output streams
    static int flops() { return 5; }
  };

/* DPCT_ORIG   double3 xpyHeavyQuarkResidualNormCuda(cudaColorSpinorField &x,
 * cudaColorSpinorField &y,*/
  cl::sycl::double3 xpyHeavyQuarkResidualNormCuda(cudaColorSpinorField &x,
                                                  cudaColorSpinorField &y,
                                                  cudaColorSpinorField &r) try {
/* DPCT_ORIG     double3 rtn =
 * reduce::reduceCuda<double3,QudaSumFloat3,QudaSumFloat,xpyHeavyQuarkResidualNorm,0,0,0,0,0,true>*/
    cl::sycl::double3 rtn =
        reduce::reduceCuda<double3, QudaSumFloat3, QudaSumFloat,
                           xpyHeavyQuarkResidualNorm, 0, 0, 0, 0, 0, true>
        /* DPCT_ORIG       (make_double2(0.0, 0.0), make_double2(0.0, 0.0), x,
           y, r, r, r);*/
        (cl::sycl::double2(0.0, 0.0), cl::sycl::double2(0.0, 0.0), x, y, r, r,
         r);
#ifdef MULTI_GPU
    rtn.z /= (x.Volume()*comm_size());
#else
/* DPCT_ORIG     rtn.z /= x.Volume();*/
    rtn.z() /= x.Volume();
#endif
    return rtn;
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

#else

  double3 HeavyQuarkResidualNormCuda(cudaColorSpinorField &x, cudaColorSpinorField &r) {
    errorQuda("Not supported on pre-Fermi architectures");
    return make_double3(0.0,0.0,0.0);
  }

  double3 xpyHeavyQuarkResidualNormCuda(cudaColorSpinorField &x, cudaColorSpinorField &y,
					cudaColorSpinorField &r) {
    errorQuda("Not supported on pre-Fermi architectures");
    return make_double3(0.0,0.0,0.0);
  }

#endif

  /**
     double3 tripleCGUpdate(V x, V y, V z){}

     First performs the operation norm2(x)
     Second performs the operatio norm2(y)
     Third performs the operation dotPropduct(y,z)
  */

  template <typename ReduceType, typename Float2, typename FloatN>
#if (__COMPUTE_CAPABILITY__ >= 200)
  struct tripleCGReduction : public ReduceFunctor<ReduceType, Float2, FloatN> {
#else
  struct tripleCGReduction {
#endif
    tripleCGReduction(const Float2 &a, const Float2 &b) { ; }
/* DPCT_ORIG     __device__ void operator()(ReduceType &sum, FloatN &x, FloatN
 * &y, FloatN &z, FloatN &w, FloatN &v)*/
    SYCL_EXTERNAL void operator()(ReduceType &sum, FloatN &x, FloatN &y,
                                  FloatN &z, FloatN &w, FloatN &v)
/* DPCT_ORIG     { sum.x += norm2_(x); sum.y += norm2_(y); sum.z += dot_(y,z);
 * }*/
    { sum.x() += norm2_(x); sum.y() += norm2_(y); sum.z() += dot_(y, z); }
    static int streams() { return 3; } //! total number of input and output streams
    static int flops() { return 6; } //! flops per element
  };

/* DPCT_ORIG   double3 tripleCGReductionCuda(cudaColorSpinorField &x,
 * cudaColorSpinorField &y, cudaColorSpinorField &z) {*/
  cl::sycl::double3 tripleCGReductionCuda(cudaColorSpinorField &x,
                                          cudaColorSpinorField &y,
                                          cudaColorSpinorField &z) try {
    return reduce::reduceCuda<double3, QudaSumFloat3, QudaSumFloat,
                              tripleCGReduction, 0, 0, 0, 0, 0, false>
        /* DPCT_ORIG       (make_double2(0.0, 0.0), make_double2(0.0, 0.0), x,
           y, z, x, x);*/
        (cl::sycl::double2(0.0, 0.0), cl::sycl::double2(0.0, 0.0), x, y, z, x,
         x);
  }
  catch (cl::sycl::exception const &exc) {
    std::cerr << exc.what() << "Exception caught at file:" << __FILE__
              << ", line:" << __LINE__ << std::endl;
    std::exit(1);
  }

} // namespace quda
