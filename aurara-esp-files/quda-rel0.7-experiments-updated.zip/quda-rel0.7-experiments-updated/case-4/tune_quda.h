#ifndef _TUNE_QUDA_H
#define _TUNE_QUDA_H

#include <quda_internal.h>
#ifndef BLAS_TEST_ONLY
#include <dirac_quda.h>
#else
#include <color_spinor_field.h>
#include <face_quda.h>
#include <blas_quda.h>
#endif //BLAS_TEST_ONLY

#include <string>
#include <iostream>
#include <iomanip>
#include <cstring>
#include <stdarg.h>
#include <tune_key.h>

namespace quda {
  /* CPU returns max number of SG, GPU returns max SG size for
 * CL_DEVICE_MAX_NUM_SUB_GROUPS device parameter. This function aligns the
 * value.
 * */
inline size_t get_sg_size(const cl::sycl::device &Device) {
  size_t max_num_sg = Device.get_info<cl::sycl::info::device::max_num_sub_groups>();
  if (Device.get_info<cl::sycl::info::device::device_type>() == cl::sycl::info::device_type::cpu) {
    size_t max_wg_size = Device.get_info<cl::sycl::info::device::max_work_group_size>();
    return max_wg_size / max_num_sg;
  }
  if (Device.get_info<cl::sycl::info::device::device_type>() == cl::sycl::info::device_type::gpu) {
    return max_num_sg;
  }
  std::cout << "Unexpected deive type" << std::endl;
  exit(1);
}


  class TuneParam {
#ifndef DPCPP_BACKEND
  public:
    dim3 block;
    dim3 grid;
    int shared_bytes;
    std::string comment;

  TuneParam() : block(32, 1, 1), grid(1, 1, 1), shared_bytes(0) { }
  TuneParam(const TuneParam &param)
    : block(param.block), grid(param.grid), shared_bytes(param.shared_bytes), comment(param.comment) { }
    TuneParam& operator=(const TuneParam &param) {
      if (&param != this) {
	block = param.block;
	grid = param.grid;
	shared_bytes = param.shared_bytes;
	comment = param.comment;
      }
      return *this;
    }

#else //DPCPP_BACKEND version

  public:
    cl::sycl::range<3> lrange;
    cl::sycl::range<3> grange;
    int local_bytes;
    std::string comment;

    cl::sycl::queue *stream;

  TuneParam() : lrange(32, 1, 1), grange(32, 1, 1), local_bytes(0), stream(nullptr) { }
  TuneParam(const TuneParam &param)
    : lrange(param.lrange), grange(param.grange), local_bytes(param.local_bytes), comment(param.comment), stream(param.stream) { }
  TuneParam& operator=(const TuneParam &param) {
    if (&param != this) {
      lrange = param.lrange;
      grange = param.grange;
      local_bytes = param.local_bytes;
      comment = param.comment;
      //stream = param.stream; //won't work with current tune cache format
    }
    return *this;
  }
  virtual ~TuneParam() { if (stream != nullptr) delete stream;}
#endif
  };


  class Tunable {

  protected:
    virtual long long flops() const = 0;
    virtual long long bytes() const { return 0; } // FIXME
#ifndef DPCPP_BACKEND
    // the minimum number of shared bytes per thread
    virtual unsigned int sharedBytesPerThread() const = 0;

    // the minimum number of shared bytes per thread block
    virtual unsigned int sharedBytesPerBlock(const TuneParam &param) const = 0;

    // override this if a specific thread count is required (e.g., if not grid size tuning)
    virtual unsigned int minThreads() const { return 1; }
    virtual bool tuneGridDim() const { return true; }
    virtual bool tuneSharedBytes() const { return true; }
#else
    // the minimum number of local bytes per thread
    virtual unsigned int localBytesPerWorkItem() const = 0;

    // the minimum number of local bytes per thread block
    virtual unsigned int localBytesPerWorkGroup(const TuneParam &param) const = 0;

    // override this if a specific thread count is required (e.g., if not grid size tuning)
    virtual unsigned int minWorkItems() const { return 1; }
    virtual bool tuneGlobalRangeDim() const { return true; }
    virtual bool tuneLocalBytes() const { return true; }
#endif

#ifndef DPCPP_BACKEND
    virtual bool advanceGridDim(TuneParam &param) const
    {
      if (tuneGridDim()) {
        const unsigned int max_blocks = 256; // FIXME: set a reasonable value for blas currently
        const int step = 1;
        param.grid.x += step;
        if (param.grid.x > max_blocks) {
          param.grid.x = step;
          return false;
        } else {
          return true;
        }
      } else {
        return false;
      }
    }
#else

    virtual bool advanceGlobalRangeDim(TuneParam &param) const
    {
      if (tuneGlobalRangeDim()) {
	const unsigned int max_work_groups = 256; // FIXME: set a reasonable value for blas currently
	const int step = param.lrange[0];
	param.grange[0] += step;//??
	if (param.grange[0] > max_work_groups*step) {
	  param.grange[0] = step;//??
	  return false;
	} else {
	  return true;
	}
      } else {
	return false;
      }
    }
#endif

#ifndef DPCPP_BACKEND
    virtual bool advanceBlockDim(TuneParam &param) const
    {
      const unsigned int max_threads = deviceProp.maxThreadsDim[0];
      const unsigned int max_blocks = deviceProp.maxGridSize[0];
      const unsigned int max_shared = deviceProp.sharedMemPerBlock;
      const int step = deviceProp.warpSize;
      bool ret;

      param.block.x += step;
      if (param.block.x > max_threads || sharedBytesPerThread()*param.block.x > max_shared) {

	if (tuneGridDim()) {
	  param.block.x = step;
	} else { // not tuning the grid dimension so have to set a valid grid size
	  // ensure the blockDim is large enough given the limit on gridDim
	  param.block = dim3((minThreads()+max_blocks-1)/max_blocks, 1, 1);
	  param.block.x = ((param.block.x+step-1)/step)*step; // round up to nearest step size
	  if(param.block.x > max_threads) errorQuda("Local lattice volume is too large for device");
	}

	ret = false;
      } else {
	ret = true;
      }

      if (!tuneGridDim())
	param.grid = dim3((minThreads()+param.block.x-1)/param.block.x, 1, 1);

      return ret;
    }
#else
    virtual bool advanceWorkGroupDim(TuneParam &param) const
    {
      if(param.stream == nullptr) errorQuda("Command queue is not defined .. \n");

      cl::sycl::device Device = param.stream->get_device();
      //const size_t max_work_items = cl::sycl::info::device::max_work_groups_size;
      const auto max_work_items  = Device.get_info<cl::sycl::info::device::max_work_item_sizes>();
      const int max_blocks = 128;//cl::sycl::info::device::max_compute_units;
      const int max_local = Device.get_info<cl::sycl::info::device::local_mem_size>();
      const int sub_group_size = get_sg_size(Device);
      bool ret;

      param.lrange[0] += sub_group_size;
      if (param.lrange[0] > max_work_items[0] || localBytesPerWorkItem()*param.lrange[0] > max_local) {

        if (tuneGlobalRangeDim()) {
          param.lrange[0] = sub_group_size;
        } else { // not tuning the grid dimension so have to set a valid grid size
          // ensure the blockDim is large enough given the limit on gridDim
          param.lrange = cl::sycl::range<3>((minWorkItems()+max_blocks-1)/max_blocks, 1, 1);
          param.lrange[0] = ((param.lrange[0]+sub_group_size-1)/sub_group_size)*sub_group_size; // round up to nearest step size
          if(param.lrange[0] > max_work_items[0]) errorQuda("Local lattice volume is too large for device");
        }

        ret = false;
      } else {
        ret = true;
      }

      if (!tuneGlobalRangeDim())
      param.grange = cl::sycl::range<3>((minWorkItems()+param.lrange[0]-1)/param.lrange[0], 1, 1);

      return ret;
    }

#endif //DPCPP_BACKEND

    /**
     * The goal here is to throttle the number of thread blocks per SM by over-allocating shared memory (in order to improve
     * L2 utilization, etc.).  Note that:
     * - On Fermi, requesting greater than 16 KB will switch the cache config, so we restrict ourselves to 16 KB for now.
     * - On GT200 and older, kernel arguments are passed via shared memory, so available space may be smaller than 16 KB.
     *   We thus request the smallest amount of dynamic shared memory that guarantees throttling to a given number of blocks,
     *   in order to allow some extra leeway.
     */
#ifndef DPCPP_BACKEND
    virtual bool advanceSharedBytes(TuneParam &param) const
    {
      if (tuneSharedBytes()) {
	const int max_shared = deviceProp.sharedMemPerBlock;
	const int max_blocks_per_sm = 8; // FIXME: derive from deviceProp
	int blocks_per_sm = max_shared / (param.shared_bytes ? param.shared_bytes : 1);
	if (blocks_per_sm > max_blocks_per_sm) blocks_per_sm = max_blocks_per_sm;
	param.shared_bytes = max_shared / blocks_per_sm + 1;
	if (param.shared_bytes > max_shared) {
	  TuneParam next(param);
	  advanceBlockDim(next); // to get next blockDim
	  int nthreads = next.block.x * next.block.y * next.block.z;
	  param.shared_bytes = sharedBytesPerThread()*nthreads > sharedBytesPerBlock(param) ?
	    sharedBytesPerThread()*nthreads : sharedBytesPerBlock(param);
	  return false;
	} else {
	  return true;
	}
      } else {
	return false;
      }
    }

#else

virtual bool advanceLocalBytes(TuneParam &param) const
{
  if(param.stream == nullptr) errorQuda("Command queue is not defined \n");

  if (tuneLocalBytes()) {
    cl::sycl::device Device = param.stream->get_device();
    const int max_local = Device.get_info<cl::sycl::info::device::local_mem_size>();;
    const int max_wg_per_cu = 8; // FIXME: derive from deviceProp
    int wg_per_cu = max_local / (param.local_bytes ? param.local_bytes : 1);
    if (wg_per_cu > max_wg_per_cu) wg_per_cu = max_wg_per_cu;
    param.local_bytes = max_local / wg_per_cu + 1;
    if (param.local_bytes > max_local) {
      TuneParam next(param);
      advanceWorkGroupDim(next); // to get next blockDim
      int nworkitems = next.lrange[0] * next.lrange[1] * next.lrange[2];
      param.local_bytes = localBytesPerWorkItem()*nworkitems > localBytesPerWorkGroup(param) ?
  localBytesPerWorkItem()*nworkitems : localBytesPerWorkGroup(param);
      return false;
    } else {
      return true;
    }
  } else {
    return false;
  }
}

#endif //DPCPP_BACKEND

    char aux[TuneKey::aux_n];

    void writeAuxString(const char *format, ...) {
      va_list arguments;
      va_start(arguments, format);
      int n = vsnprintf(aux, TuneKey::aux_n, format, arguments);
      //int n = snprintf(aux, QUDA_TUNE_AUX_STR_LENGTH, "threads=%d,prec=%lu,stride=%d,geometery=%d",
      //	       arg.volumeCB,sizeof(Complex)/2,arg.forceOffset);
      if (n < 0 || n >= 512) errorQuda("Error writing auxiliary string");
    }

  public:
    Tunable() { }
    virtual ~Tunable() { }
    virtual TuneKey tuneKey() const = 0;
#ifndef DPCPP_BACKEND
    virtual void apply(const cudaStream_t &stream) = 0;
#else
    virtual void apply(cl::sycl::queue* &stream) = 0;
#endif
    virtual void preTune() { }
    virtual void postTune() { }
    virtual int tuningIter() const { return 1; }

    virtual std::string paramString(const TuneParam &param) const
      {
	std::stringstream ps;
  #ifndef DPCPP_BACKEND
	ps << "block=(" << param.block.x << "," << param.block.y << "," << param.block.z << "), ";
	ps << "grid=(" << param.grid.x << "," << param.grid.y << "," << param.grid.z << "), ";
	ps << "shared=" << param.shared_bytes;
  #else
  ps << "block=(" << param.lrange[0] << "," << param.lrange[1] << "," << param.lrange[2] << "), ";
	ps << "grid=(" << param.grange[0] << "," << param.grange[1] << "," << param.grange[2] << "), ";
	ps << "shared=" << param.local_bytes;
  #endif
	return ps.str();
      }

    virtual std::string perfString(float time) const
      {
	float gflops = flops() / (1e9 * time);
	float gbytes = bytes() / (1e9 * time);
	std::stringstream ss;
	ss << std::setiosflags(std::ios::fixed) << std::setprecision(2) << gflops << " Gflop/s, ";
	ss << gbytes << " GB/s";
	return ss.str();
      }

    virtual void initTuneParam(TuneParam &param) const
    {
#ifndef DPCPP_BACKEND
      const unsigned int max_threads = deviceProp.maxThreadsDim[0];
      const unsigned int max_blocks = deviceProp.maxGridSize[0];
      const int min_block_size = deviceProp.warpSize;

      if (tuneGridDim()) {
	param.block = dim3(min_block_size,1,1);

	param.grid = dim3(1,1,1);
      } else {
	// find the minimum valid blockDim
	const int warp = deviceProp.warpSize;
	param.block = dim3((minThreads()+max_blocks-1)/max_blocks, 1, 1);
	param.block.x = ((param.block.x+warp-1) / warp) * warp; // round up to the nearest warp
	if (param.block.x > max_threads) errorQuda("Local lattice volume is too large for device");

	param.grid = dim3((minThreads()+param.block.x-1)/param.block.x, 1, 1);
      }
      param.shared_bytes = sharedBytesPerThread()*param.block.x > sharedBytesPerBlock(param) ?
	sharedBytesPerThread()*param.block.x : sharedBytesPerBlock(param);

#else
  if(param.stream == nullptr) errorQuda("Command queue is not defined \n");

  cl::sycl::device Device = param.stream->get_device();

  const auto maxWorkItemSizes = Device.get_info<cl::sycl::info::device::max_work_item_sizes>();

  const unsigned int max_work_items = maxWorkItemSizes[0];
  const unsigned int max_work_groups= 128;//deviceProp.maxGridSize[0];//???
  const int          min_wg_size    = get_sg_size(Device);

  if (tuneGlobalRangeDim()) {
    param.lrange = cl::sycl::range<3>(min_wg_size,1,1);

    param.grange = cl::sycl::range<3>(1,1,1);
  } else {
    // find the minimum valid blockDim
    const int sub_group_size = get_sg_size(Device);
    param.lrange    = cl::sycl::range<3>((minWorkItems()+max_work_groups-1)/max_work_groups, 1, 1);
    param.lrange[0] = ((param.lrange[0]+sub_group_size-1) / sub_group_size) * sub_group_size;

    if (param.lrange[0] > max_work_items) errorQuda("Local lattice volume is too large for device");

     param.grange = cl::sycl::range<3>((minWorkItems()+param.lrange[0]-1)/param.lrange[0]*param.lrange[0], 1, 1);
  }
  param.local_bytes = localBytesPerWorkItem()*param.lrange[0] > localBytesPerWorkGroup(param) ?
localBytesPerWorkItem()*param.lrange[0] : localBytesPerWorkGroup(param);

#endif //DPCPP_BACKEND
    }

    /** sets default values for when tuning is disabled */
    virtual void defaultTuneParam(TuneParam &param) const
    {
      initTuneParam(param);
#ifndef DPCPP_BACKEND
      if (tuneGridDim()) param.grid = dim3(128,1,1);
#else
      if (tuneGlobalRangeDim()) param.grange = cl::sycl::range<3>(128*param.lrange[0],1,1);
#endif
    }

    virtual bool advanceTuneParam(TuneParam &param) const
    {
#ifndef DPCPP_BACKEND
      return advanceSharedBytes(param) || advanceBlockDim(param) || advanceGridDim(param);
#else
      return advanceLocalBytes(param) || advanceWorkGroupDim(param) || advanceGlobalRangeDim(param);
#endif
    }

    /**
     * Check the launch parameters of the kernel to ensure that they are
     * valid for the current device.
     */
    void checkLaunchParam(TuneParam &param) {
#ifndef DPCPP_BACKEND
      if (param.block.x > (unsigned int)deviceProp.maxThreadsDim[0])
	errorQuda("Requested X-dimension block size %d greater than hardware limit %d",
		  param.block.x, deviceProp.maxThreadsDim[0]);

      if (param.block.y > (unsigned int)deviceProp.maxThreadsDim[1])
	errorQuda("Requested Y-dimension block size %d greater than hardware limit %d",
		  param.block.y, deviceProp.maxThreadsDim[1]);

      if (param.block.z > (unsigned int)deviceProp.maxThreadsDim[2])
	errorQuda("Requested Z-dimension block size %d greater than hardware limit %d",
		  param.block.z, deviceProp.maxThreadsDim[2]);

      if (param.grid.x > (unsigned int)deviceProp.maxGridSize[0]){
	errorQuda("Requested X-dimension grid size %d greater than hardware limit %d",
		  param.grid.x, deviceProp.maxGridSize[0]);

      }
      if (param.grid.y > (unsigned int)deviceProp.maxGridSize[1])
	errorQuda("Requested Y-dimension grid size %d greater than hardware limit %d",
		  param.grid.y, deviceProp.maxGridSize[1]);

      if (param.grid.z > (unsigned int)deviceProp.maxGridSize[2])
	errorQuda("Requested Z-dimension grid size %d greater than hardware limit %d",
		  param.grid.z, deviceProp.maxGridSize[2]);
#else
      if(param.stream == nullptr) errorQuda("Command queue is not defined \n");

      cl::sycl::device Device = param.stream->get_device();

      const auto maxWorkItemSizes = Device.get_info<cl::sycl::info::device::max_work_item_sizes>();

      if (param.lrange[0] > (unsigned int)maxWorkItemSizes[0])
  errorQuda("Requested X-dimension block size %d greater than hardware limit %d",
      param.lrange[0], maxWorkItemSizes);

      if (param.lrange[1] > (unsigned int)maxWorkItemSizes[1])
  errorQuda("Requested Y-dimension block size %d greater than hardware limit %d",
      param.lrange[1], maxWorkItemSizes[1]);

      if (param.lrange[2] > (unsigned int)maxWorkItemSizes[2])
  errorQuda("Requested Y-dimension block size %d greater than hardware limit %d",
      param.lrange[2], maxWorkItemSizes[2]);

      //Q: how to check global range size?
#endif //DPCPP_BACKEND
    }

  };

  void loadTuneCache(QudaVerbosity verbosity);
  void saveTuneCache(QudaVerbosity verbosity);
  TuneParam& tuneLaunch(Tunable &tunable, QudaTune enabled, QudaVerbosity verbosity);

} // namespace quda

#endif // _TUNE_QUDA_H
