
dpcpp -DDPCPP_BACKEND -DBLAS_TEST_ONLY -I${DPCT_BUNDLE_ROOT}/include -I./include  -L/opt/intel/2021.1.4/inteloneapi/compiler/latest/linux/lib -lOpenCL -lsycl -c -o tune.cpp.dp.o tune.cpp.dp.cpp
