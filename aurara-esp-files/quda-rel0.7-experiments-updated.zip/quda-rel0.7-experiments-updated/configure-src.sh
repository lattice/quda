
./configure --enable-multi-gpu --with-mpi=/opt/intel/2021.1.4/inteloneapi/mpi/2021.1-beta04 CC=mpicc CXX=mpicxx
