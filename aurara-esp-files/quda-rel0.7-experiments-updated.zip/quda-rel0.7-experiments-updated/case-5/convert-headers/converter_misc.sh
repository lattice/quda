#!/bin/bash

CUDA_HOME=/usr/local/cuda-10.1
QUDA_HOME=`pwd`
PROJ_DIR=$QUDA_HOME/lib

test_version_=$(date +%s)

OUTDIR=custom_output_${test_version_}


dpct -p -in-root=$PROJ_DIR -out-root=$OUTDIR \
     --keep-original-code \
     --extra-arg='-I$QUDA_HOME/include' \
     --extra-arg='-std=c++14' \
     $QUDA_HOME/devel/convert/register_traits.cuh

dpct -p -in-root=$PROJ_DIR -out-root=$OUTDIR \
     --keep-original-code \
     --extra-arg='-I$QUDA_HOME/devel/include' \
     --extra-arg='-std=c++14' \
     --extra-arg='-I$QUDA_HOME/devel/convert' \
     --extra-arg='-I/opt/cuda-10.1/include' \
     $QUDA_HOME/devel/convert/color_spinor_field_order.cu



