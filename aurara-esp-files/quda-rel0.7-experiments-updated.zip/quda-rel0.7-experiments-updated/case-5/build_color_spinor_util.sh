
dpcpp -DDPCPP_BACKEND -DBLAS_TEST_ONLY -I../lib -I${DPCT_BUNDLE_ROOT}/include -I./include  -L/opt/intel/2021.1.4/inteloneapi/compiler/latest/linux/lib -lOpenCL -lsycl -c -o color_spinor_util.cpp.dp.o color_spinor_util.dp.cpp
