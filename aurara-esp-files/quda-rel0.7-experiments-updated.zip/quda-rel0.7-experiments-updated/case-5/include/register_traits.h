#ifndef REGISTER_TRAITS_H
#define REGISTER_TRAITS_H

#include <quda_internal.h>

namespace quda {

  /*
    Here we use traits to define the mapping between storage type and
    register type:
    double -> double
    float -> float
    short -> float
    This allows us to wrap the encapsulate the register type into the storage template type
   */
  template<typename> struct mapper { };
  template<> struct mapper<double> { typedef double type; };
  template<> struct mapper<float> { typedef float type; };
  template<> struct mapper<short> { typedef float type; };

/* DPCT_ORIG   template<> struct mapper<cl::sycl::double2> { typedef double2 type; };*/
  template <> struct mapper<cl::sycl::double2> { typedef cl::sycl::double2 type; };
/* DPCT_ORIG   template<> struct mapper<cl::sycl::float2> { typedef float2 type; };*/
  template <> struct mapper<cl::sycl::float2> { typedef cl::sycl::float2 type; };
/* DPCT_ORIG   template<> struct mapper<cl::sycl::short2> { typedef float2 type; };*/
  template <> struct mapper<cl::sycl::short2> { typedef cl::sycl::float2 type; };

/* DPCT_ORIG   template<> struct mapper<cl::sycl::double4> { typedef double4 type; };*/
  template <> struct mapper<cl::sycl::double4> { typedef cl::sycl::double4 type; };
/* DPCT_ORIG   template<> struct mapper<cl::sycl::float4> { typedef float4 type; };*/
  template <> struct mapper<cl::sycl::float4> { typedef cl::sycl::float4 type; };
/* DPCT_ORIG   template<> struct mapper<cl::sycl::short4> { typedef float4 type; };*/
  template <> struct mapper<cl::sycl::short4> { typedef cl::sycl::float4 type; };

  /* Traits used to determine if a variable is half precision or not */
  template< typename T > struct isHalf{ static const bool value = false; };
  template<> struct isHalf<short>{ static const bool value = true; };

/* DPCT_ORIG   template<typename T1, typename T2> __host__ __device__ inline
 * void copy (T1 &a, const T2 &b) { a = b; }*/
  template <typename T1, typename T2> inline void copy(T1 &a, const T2 &b) { a = b; }
/* DPCT_ORIG   template<> __host__ __device__ inline void copy(float &a, const
 * short &b) { a = (float)b/MAX_SHORT; }*/
  template <> inline void copy(float &a, const short &b) { a = (float)b/MAX_SHORT; }
/* DPCT_ORIG   template<> __host__ __device__ inline void copy(short &a, const
 * float &b) { a = (short)(b*MAX_SHORT); }*/
  template <> inline void copy(short &a, const float &b) { a = (short)(b*MAX_SHORT); }

  /**
     Generic wrapper for Trig functions
  */
  template <bool isHalf>
    struct Trig {
      template <typename T>
      /* DPCT_ORIG       __device__ __host__ static T Atan2( const T &a, const T
         &b) { return atan2(a,b); }*/
      static T Atan2(const T &a, const T &b) { return atan2(a,b); }
      template <typename T>
      /* DPCT_ORIG       __device__ __host__ static T Sin( const T &a ) { return
         sin(a); }*/
      static T Sin(const T &a) { return sin(a); }
      template <typename T>
      /* DPCT_ORIG       __device__ __host__ static T Cos( const T &a ) { return
         cos(a); }*/
      static T Cos(const T &a) { return cos(a); }

      template <typename T>
      /* DPCT_ORIG       __device__ __host__ static void SinCos(const T& a, T
         *s, T *c) { *s = sin(a); *c = cos(a); }*/
      static void SinCos(const T &a, T *s, T *c) { *s = sin(a); *c = cos(a); }
    };

  /**
     Specialization of Trig functions using shorts
   */
  template <>
    struct Trig<true> {
    template <typename T>
    /* DPCT_ORIG       __device__ __host__ static T Atan2( const T &a, const T
       &b) { return atan2(a,b)/M_PI; }*/
    static T Atan2(const T &a, const T &b) { return atan2(a,b)/M_PI; }
    template <typename T>
    /* DPCT_ORIG       __device__ __host__ static T Sin( const T &a ) { return
       sin(a*M_PI); }*/
    static T Sin(const T &a) { return sin(a*M_PI); }
    template <typename T>
    /* DPCT_ORIG       __device__ __host__ static T Cos( const T &a ) { return
       cos(a*M_PI); }*/
    static T Cos(const T &a) { return cos(a*M_PI); }
  };




} // namespace quda

#endif
