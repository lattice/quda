
dpcpp -DDPCPP_BACKEND -I${DPCT_BUNDLE_ROOT}/include -I./include  -L/opt/intel/2021.1.4/inteloneapi/compiler/latest/linux/lib -lOpenCL -lsycl -c -o comm_mpi.cpp.dp.o comm_mpi.cpp.dp.cpp
